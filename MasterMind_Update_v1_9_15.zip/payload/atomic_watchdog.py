"""Independent entry point: remains outside all replaceable release folders."""
import argparse
import sys
from pathlib import Path
from atomic_core import run_watchdog

def main():
    p=argparse.ArgumentParser(description='MasterMind independent atomic update watchdog')
    p.add_argument('--root',default=str(Path(__file__).resolve().parent))
    p.add_argument('--mode',choices=['serve','apply','takeover'],default='serve')
    p.add_argument('--package');p.add_argument('--port',type=int)
    args=p.parse_args()
    try:run_watchdog(args.root,args.mode,args.package,args.port)
    except Exception as exc:
        print('MasterMind watchdog stopped safely: '+str(exc),file=sys.stderr,flush=True)
        return 1
    return 0

if __name__=='__main__':raise SystemExit(main())
