"""MasterMind knowledge/preset persistence. Engine code never edits built-in knowledge."""
from __future__ import annotations

import copy
import json
import os
import re
import secrets
from datetime import datetime
from pathlib import Path
from typing import Any

FORMAT = "mastermind.knowledge.v1"
PATCH_FORMAT = "mastermind.knowledge.patch.v1"
PRESET_FORMAT = "mastermind.presets.v1"
ALLOWED_ROOTS = {"lists", "palettes", "recipes", "presets", "defaults", "rules", "templates"}
IDENTITY_KEYS = ("id", "reference", "name", "value", "label")
MINIMUMS = {
    "presets.producers": 115,
    "presets.styles": 290,
    "presets.blueprints": 166,
    "presets.artists": 2,
    "presets.style_shortcuts": 18,
    "recipes.production_architectures": 6,
}
UNIQUE_LISTS = {
    "palettes.energy", "palettes.moods", "palettes.colors", "palettes.contrast",
    "recipes.production_worlds", "recipes.production_architectures",
    "presets.style_shortcuts", "presets.producers", "presets.styles", "presets.blueprints",
    "lists.route_stop_words",
}


class KnowledgeError(ValueError):
    pass


def read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return copy.deepcopy(default)


def write_json_atomic(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + "." + secrets.token_hex(6) + ".tmp")
    try:
        with tmp.open("x", encoding="utf-8", newline="\n") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
            f.write("\n");f.flush();os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def normalize(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def identity(value: Any) -> str:
    if isinstance(value, dict):
        for key in IDENTITY_KEYS:
            if key in value and str(value[key]).strip():
                return key + ":" + normalize(value[key])
        return "json:" + json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return type(value).__name__ + ":" + normalize(value)


def forbidden_hits(value: Any, path: str = "", skip_rule=True) -> list[str]:
    if skip_rule and path == "rules.banned_words":
        return []
    hits: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            p = f"{path}.{key}" if path else str(key)
            hits.extend(forbidden_hits(child, p, skip_rule))
    elif isinstance(value, list):
        for i, child in enumerate(value):
            hits.extend(forbidden_hits(child, f"{path}[{i}]", skip_rule))
    elif isinstance(value, str):
        if re.search(r"\blow(?:[\W_])*light(?:s|ing|ed)?\b", value, re.I):
            hits.append(path or "value")
    return hits


def duplicates(values: list[Any], path: str) -> list[str]:
    seen: dict[str, int] = {}
    out: list[str] = []
    for i, value in enumerate(values):
        key = identity(value)
        if key in seen:
            out.append(f"{path}[{i}] duplicates [{seen[key]}] ({key})")
        else:
            seen[key] = i
    return out


def get_path(root: Any, path: str) -> Any:
    node = root
    for segment in path.split("."):
        if isinstance(node, dict):
            if segment not in node:
                raise KnowledgeError(f"Unknown knowledge path: {path}")
            node = node[segment]
        elif isinstance(node, list):
            matches = [x for x in node if identity(x).split(":", 1)[-1] == normalize(segment)]
            if len(matches) != 1:
                raise KnowledgeError(f"List selector '{segment}' at {path} matched {len(matches)} entries")
            node = matches[0]
        else:
            raise KnowledgeError(f"Knowledge path does not lead to a container: {path}")
    return node


def parent_path(root: Any, path: str) -> tuple[Any, str]:
    parts = path.split(".")
    if not parts or parts[0] not in ALLOWED_ROOTS:
        raise KnowledgeError(f"Patch path must begin with one of: {', '.join(sorted(ALLOWED_ROOTS))}")
    if path == "rules.banned_words" or path.startswith("rules.banned_words."):
        raise KnowledgeError("The banned-word rule cannot be changed by a patch")
    if len(parts) < 2:
        raise KnowledgeError("Patch paths must target a named knowledge list or field, not a whole section")
    parent = root if len(parts) == 1 else get_path(root, ".".join(parts[:-1]))
    return parent, parts[-1]


def resolve_member(parent: Any, token: str, full_path: str) -> tuple[str, Any]:
    if isinstance(parent, dict):
        if token not in parent:
            raise KnowledgeError(f"Unknown knowledge path: {full_path}")
        return "key", token
    if isinstance(parent, list):
        target = normalize(token)
        matches = [i for i, item in enumerate(parent) if identity(item).split(":", 1)[-1] == target]
        if len(matches) != 1:
            raise KnowledgeError(f"List selector '{token}' at {full_path} matched {len(matches)} entries")
        return "index", matches[0]
    raise KnowledgeError(f"Knowledge path does not lead to a container: {full_path}")


def validate_pack(pack: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(pack, dict) or pack.get("format") != FORMAT or pack.get("schema_version") != 1:
        return ["Knowledge pack format/schema is not supported"]
    for section in ALLOWED_ROOTS:
        if not isinstance(pack.get(section), dict):
            errors.append(f"Missing object section: {section}")
    errors.extend(f"Banned word found at {p}" for p in forbidden_hits(pack))
    if errors:
        return errors
    for path, minimum in MINIMUMS.items():
        try:
            value = get_path(pack, path)
            count = len(value) if isinstance(value, (list, dict)) else -1
            if count < minimum:
                errors.append(f"{path} requires at least {minimum} entries; found {count}")
        except KnowledgeError as exc:
            errors.append(str(exc))
    unique_paths = set(UNIQUE_LISTS)
    unique_paths.update("lists.select_options." + k for k in (pack.get("lists", {}).get("select_options", {}) or {}))
    unique_paths.update("lists.lyric_lexicon." + k for k in (pack.get("lists", {}).get("lyric_lexicon", {}) or {}))
    for path in sorted(unique_paths):
        try:
            value = get_path(pack, path)
            if not isinstance(value, list):
                errors.append(f"Knowledge list must be an array: {path}")
            else:
                errors.extend(duplicates(value, path))
        except KnowledgeError as exc:
            errors.append(str(exc))
    for item in pack.get("palettes", {}).get("moods", []):
        if not isinstance(item, dict) or not str(item.get("name") or "").strip() or not str(item.get("mechanics") or "").strip():
            errors.append("Every mood requires name and mechanics")
    for item in pack.get("palettes", {}).get("colors", []):
        if not isinstance(item, dict) or not str(item.get("name") or "").strip() or not str(item.get("mechanics") or "").strip():
            errors.append("Every color requires name and mechanics")
    return errors


def load_effective(builtin_path: Path, custom_path: Path) -> dict[str, Any]:
    builtin = read_json(builtin_path, {})
    errors = validate_pack(builtin)
    if errors:
        raise KnowledgeError("Built-in knowledge is invalid: " + "; ".join(errors[:8]))
    if custom_path.is_file():
        custom = read_json(custom_path, {})
        errors = validate_pack(custom)
        if errors:
            raise KnowledgeError("Custom knowledge is invalid: " + "; ".join(errors[:8]))
        return custom
    return builtin


def apply_patch_document(pack: dict[str, Any], patch: Any) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    if not isinstance(patch, dict) or not any(k in patch for k in ("add", "remove", "replace")):
        raise KnowledgeError('Patch must be an object containing "add", "remove", or "replace"')
    extra = set(patch) - {"format", "description", "add", "remove", "replace"}
    if extra:
        raise KnowledgeError("Unknown patch keys: " + ", ".join(sorted(extra)))
    hits = forbidden_hits({k: v for k, v in patch.items() if k != "description"}, skip_rule=False)
    if hits:
        raise KnowledgeError("Patch rejected: banned word found at " + ", ".join(hits))
    result = copy.deepcopy(pack)
    changes: list[dict[str, Any]] = []

    for operation in ("add", "remove", "replace"):
        block = patch.get(operation, {})
        if block is None:
            continue
        if not isinstance(block, dict):
            raise KnowledgeError(f'"{operation}" must be an object keyed by knowledge path')
        for path, value in block.items():
            if not isinstance(path, str) or not path.strip():
                raise KnowledgeError("Patch paths must be non-empty strings")
            if operation == "add":
                target = get_path(result, path)
                if isinstance(target, list):
                    items = value if isinstance(value, list) else [value]
                    existing = {identity(x) for x in target}
                    for item in items:
                        key = identity(item)
                        if key in existing:
                            raise KnowledgeError(f"Duplicate addition at {path}: {key}")
                        target.append(copy.deepcopy(item));existing.add(key)
                        changes.append({"operation": "add", "path": path, "after": item})
                elif isinstance(target, dict) and isinstance(value, dict):
                    for key, item in value.items():
                        if key in target:
                            raise KnowledgeError(f"Duplicate object key at {path}.{key}")
                        target[key] = copy.deepcopy(item)
                        changes.append({"operation": "add", "path": f"{path}.{key}", "after": item})
                else:
                    raise KnowledgeError(f"Add target must be a list, or an object with an object value: {path}")
            elif operation == "remove":
                target = get_path(result, path)
                if isinstance(target, list):
                    selectors = value if isinstance(value, list) else [value]
                    for selector in selectors:
                        key = identity(selector)
                        matches = [i for i, item in enumerate(target) if identity(item) == key]
                        if len(matches) != 1:
                            raise KnowledgeError(f"Remove selector at {path} matched {len(matches)} entries: {key}")
                        before = target.pop(matches[0])
                        changes.append({"operation": "remove", "path": path, "before": before})
                elif isinstance(target, dict):
                    keys = value if isinstance(value, list) else [value]
                    for key in keys:
                        if not isinstance(key, str) or key not in target:
                            raise KnowledgeError(f"Remove key does not exist at {path}: {key}")
                        before = target.pop(key)
                        changes.append({"operation": "remove", "path": f"{path}.{key}", "before": before})
                else:
                    raise KnowledgeError(f"Remove target must be a list or object: {path}")
            else:
                parent, token = parent_path(result, path)
                kind, member = resolve_member(parent, token, path)
                before = parent[member]
                parent[member] = copy.deepcopy(value)
                changes.append({"operation": "replace", "path": path, "before": before, "after": value})

    if not changes:
        raise KnowledgeError("Patch contains no changes")
    errors = validate_pack(result)
    if errors:
        raise KnowledgeError("Patched knowledge failed validation: " + "; ".join(errors[:12]))
    return result, changes


def apply_and_save(builtin_path: Path, custom_path: Path, history_path: Path, patch: Any) -> dict[str, Any]:
    current = load_effective(builtin_path, custom_path)
    result, changes = apply_patch_document(current, patch)
    history = read_json(history_path, [])
    if not isinstance(history, list):
        history = []
    record = {"applied_at": datetime.now().isoformat(timespec="seconds"), "patch": patch, "changes": changes}
    write_json_atomic(custom_path, result)
    try:
        write_json_atomic(history_path, [*history, record])
    except Exception:
        # The knowledge itself is valid and durable; do not corrupt it if only audit write fails.
        raise KnowledgeError("Knowledge applied, but patch-history write failed; export before applying another patch")
    return {"ok": True, "changes": changes, "change_count": len(changes), "knowledge": result}
