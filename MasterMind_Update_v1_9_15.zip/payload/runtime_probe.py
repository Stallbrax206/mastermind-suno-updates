"""Isolated, offline runtime checks used by staging and live verification."""
from __future__ import annotations
import json
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path


def available_port():
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        return sock.getsockname()[1]


def request(base, path, body=None):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(base + path, data=data,
                                 headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=2) as resp:
        return json.load(resp)


def launch(root, port, token, validation=False):
    env = dict(os.environ)
    env.update(MASTERMIND_VERIFY_PORT=str(port), MASTERMIND_VERIFY_TOKEN=token,
               MASTERMIND_NO_BROWSER='1')
    env.pop('MASTERMIND_VALIDATION', None)
    if validation:
        env['MASTERMIND_VALIDATION'] = '1'
        env.pop('OPENAI_API_KEY', None)
    return subprocess.Popen([sys.executable, '-B', str(Path(root)/'app.py')],
                            cwd=str(root), env=env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def stop(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)


def verify(proc, root, port, version, token, timeout=12):
    base = f'http://127.0.0.1:{port}'
    deadline = time.monotonic() + timeout
    last = 'not started'
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            raise RuntimeError(f'Candidate server exited with code {proc.returncode}')
        try:
            health = request(base, '/api/health')
            if not (health.get('ok') is True and health.get('version') == version
                    and health.get('runtime_token') == token
                    and health.get('runtime_pid') == proc.pid
                    and Path(health.get('runtime_root', '')).resolve() == Path(root).resolve()):
                raise RuntimeError('Runtime identity or release health mismatch')
            break
        except Exception as exc:
            last = str(exc)
            time.sleep(.1)
    else:
        raise RuntimeError('Runtime did not become healthy: ' + last)
    result = request(base, '/api/system/selftest')
    if result.get('ok') is not True:
        bad = [c.get('name') for c in result.get('checks', []) if not c.get('ok')]
        raise RuntimeError('Running-app integrity check failed: ' + str(bad))
    boot = request(base, '/api/bootstrap')
    if boot.get('release_contract', {}).get('version') != version:
        raise RuntimeError('Running bootstrap contract mismatch')
    return base, health
