from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path, PurePosixPath
from typing import Any

CONTRACT_NAME = "release_contract.json"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_contract(root: Path) -> dict[str, Any]:
    path = Path(root) / CONTRACT_NAME
    obj = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise RuntimeError("Release contract must be a JSON object.")
    return obj


def contract_version(root: Path) -> str:
    return str(load_contract(root).get("version") or "").strip()


def installed_version(root: Path) -> str:
    try:
        return (Path(root) / "VERSION.txt").read_text(encoding="utf-8").strip().lstrip("vV")
    except Exception:
        return ""


def normalize_rel(path: str) -> str:
    p = PurePosixPath(str(path or "").replace("\\", "/").lstrip("/"))
    if p.is_absolute() or ".." in p.parts:
        raise RuntimeError(f"Unsafe contract path: {path}")
    return str(p)


def protected_policy(contract: dict[str, Any]) -> tuple[set[str], tuple[str, ...]]:
    policy = contract.get("user_data_policy") or {}
    exact = {normalize_rel(x) for x in (policy.get("protected_exact") or [])}
    prefixes = tuple(normalize_rel(x).rstrip("/") + "/" if not str(x).endswith("_") else normalize_rel(x)
                     for x in (policy.get("protected_prefixes") or []))
    return exact, prefixes


def is_protected(rel: str, contract: dict[str, Any]) -> bool:
    rel = normalize_rel(rel)
    exact, prefixes = protected_policy(contract)
    return rel in exact or any(rel.startswith(p) for p in prefixes)


def flatten_ui_spec(contract: dict[str, Any]) -> dict[str, list[str]]:
    ids: list[str] = []
    funcs: list[str] = []
    for cap in (contract.get("capabilities") or {}).values():
        if not isinstance(cap, dict) or cap.get("required") is False:
            continue
        ui = cap.get("ui") or {}
        ids.extend(str(x) for x in (ui.get("ids") or []) if str(x).strip())
        funcs.extend(str(x) for x in (ui.get("functions") or []) if str(x).strip())
    # stable de-dupe
    return {
        "ids": list(dict.fromkeys(ids)),
        "functions": list(dict.fromkeys(funcs)),
    }


def parse_ui_structure(html_text: str) -> dict[str, set[str]]:
    ids = set(re.findall(r'\bid=["\']([^"\']+)["\']', html_text, flags=re.I))
    funcs = set(re.findall(r'\b(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(', html_text))
    return {"ids": ids, "functions": funcs}


def _json_count(path: Path) -> int:
    obj = json.loads(path.read_text(encoding="utf-8"))
    return len(obj) if isinstance(obj, (list, dict)) else -1


def verify_program_hashes(root: Path, contract: dict[str, Any]) -> list[str]:
    root = Path(root)
    errors: list[str] = []
    for rel, expected in (contract.get("program_files") or {}).items():
        rel = normalize_rel(rel)
        path = root / rel
        if not path.is_file():
            errors.append(f"missing program file: {rel}")
            continue
        got = sha256_file(path)
        if str(expected).lower() != got.lower():
            errors.append(f"program hash mismatch: {rel}")
    return errors


def user_data_files(root: Path, contract: dict[str, Any]) -> list[Path]:
    root = Path(root)
    exact, prefixes = protected_policy(contract)
    found: set[Path] = set()
    for rel in exact:
        p = root / rel
        if p.is_file():
            found.add(p)
        elif p.is_dir():
            found.update(x for x in p.rglob("*") if x.is_file())
    # Prefixes can mean a directory prefix (data/projects/) or filename prefix (data/custom_)
    for prefix in prefixes:
        raw = prefix
        if raw.endswith("/"):
            base = root / raw.rstrip("/")
            if base.is_dir():
                found.update(x for x in base.rglob("*") if x.is_file())
        else:
            parent = root / Path(raw).parent
            stem_prefix = Path(raw).name
            if parent.is_dir():
                found.update(x for x in parent.iterdir() if x.is_file() and x.name.startswith(stem_prefix))
    return sorted(found)


def user_data_fingerprint(root: Path, contract: dict[str, Any]) -> dict[str, str]:
    root = Path(root)
    out: dict[str, str] = {}
    for path in user_data_files(root, contract):
        rel = path.relative_to(root).as_posix()
        out[rel] = sha256_file(path)
    return out


def validate_release(root: Path, client_ui_report: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """Validate the installed release against one machine-readable contract.

    This is deliberately shared by the live app, regression suite, and updater.
    No version-specific UI/schema literals should live in those callers.
    """
    root = Path(root)
    checks: list[dict[str, Any]] = []

    def add(name: str, ok: bool, detail: Any, severity: str = "fail"):
        checks.append({"name": name, "ok": bool(ok), "detail": str(detail), "severity": severity})

    try:
        contract = load_contract(root)
    except Exception as exc:
        add("Release contract", False, exc)
        return checks

    cver = str(contract.get("version") or "").strip().lstrip("vV")
    iver = installed_version(root)
    add("Release contract version", bool(cver) and cver == iver, f"contract v{cver or '?'} / installed v{iver or '?'}")
    add("Release contract schema", int(contract.get("contract_version") or 0) >= 1, f"contract schema {contract.get('contract_version')}")

    hash_errors = verify_program_hashes(root, contract)
    add("Installed program file hashes", not hash_errors, "all match release contract" if not hash_errors else "; ".join(hash_errors[:5]))

    # Bank counts and required data files are contract-driven.
    for rel, spec in (contract.get("data_requirements") or {}).items():
        path = root / normalize_rel(rel)
        label = str((spec or {}).get("label") or rel)
        min_count = int((spec or {}).get("min_count") or 0)
        try:
            count = _json_count(path)
            add(label, count >= min_count, f"{count} entries; minimum {min_count}")
        except Exception as exc:
            add(label, False, exc)

    # Static UI-on-disk contract: actual DOM ids and declared functions, not brittle schema text markers.
    ui_path = root / "static" / "index.html"
    try:
        html = ui_path.read_text(encoding="utf-8", errors="replace")
        actual = parse_ui_structure(html)
        spec = flatten_ui_spec(contract)
        missing_ids = [x for x in spec["ids"] if x not in actual["ids"]]
        missing_funcs = [x for x in spec["functions"] if x not in actual["functions"]]
        add("UI contract on disk", not missing_ids and not missing_funcs,
            "all required controls/functions present" if not missing_ids and not missing_funcs
            else f"missing ids={missing_ids[:8]} functions={missing_funcs[:8]}")
    except Exception as exc:
        add("UI contract on disk", False, exc)

    # Browser handshake validates the UI the user is actually running, catching stale-cache or partial-deploy cases.
    if client_ui_report is not None:
        expected = flatten_ui_spec(contract)
        loaded_ver = str(client_ui_report.get("version") or "").strip().lstrip("vV")
        ids = client_ui_report.get("ids") or {}
        funcs = client_ui_report.get("functions") or {}
        missing_loaded_ids = [x for x in expected["ids"] if not bool(ids.get(x))]
        missing_loaded_funcs = [x for x in expected["functions"] if not bool(funcs.get(x))]
        add("Live browser release version", loaded_ver == cver, f"browser v{loaded_ver or '?'} / contract v{cver or '?'}")
        add("Live browser UI handshake", not missing_loaded_ids and not missing_loaded_funcs,
            "loaded page matches release contract" if not missing_loaded_ids and not missing_loaded_funcs
            else f"missing ids={missing_loaded_ids[:8]} functions={missing_loaded_funcs[:8]}")
    else:
        add("Live browser UI handshake", True, "not supplied; disk UI contract checked", severity="warn")

    # Backend route contract is derived from the same capability registry.
    try:
        app_text = (root / "app.py").read_text(encoding="utf-8", errors="replace")
        routes: list[str] = []
        for cap in (contract.get("capabilities") or {}).values():
            if not isinstance(cap, dict) or cap.get("required") is False:
                continue
            routes.extend(str(x) for x in (cap.get("backend_routes") or []) if str(x).strip())
        routes = list(dict.fromkeys(routes))
        missing_routes = [r for r in routes if r not in app_text]
        add("Backend capability routes", not missing_routes, "all required routes present" if not missing_routes else f"missing {missing_routes[:8]}")
    except Exception as exc:
        add("Backend capability routes", False, exc)

    policy = contract.get("user_data_policy") or {}
    exact, prefixes = protected_policy(contract)
    add("Protected user-data contract", bool(exact) and bool(prefixes), f"{len(exact)} exact paths; {len(prefixes)} protected prefixes")
    add("Release migration policy", bool(contract.get("migration_policy")), str(contract.get("migration_policy") or "missing"))
    return checks


def checks_ok(checks: list[dict[str, Any]]) -> tuple[bool, bool]:
    fails = [c for c in checks if not c.get("ok") and c.get("severity", "fail") == "fail"]
    warns = [c for c in checks if not c.get("ok") and c.get("severity") == "warn"]
    return (not fails, bool(warns))
