from __future__ import annotations

import argparse
import hashlib
import json
import os
import py_compile
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile
import secrets
from contextlib import contextmanager
from runtime_probe import available_port, launch as launch_runtime, stop as stop_runtime, verify as verify_runtime
from datetime import datetime
from pathlib import Path, PurePosixPath

from release_integrity import (
    CONTRACT_NAME,
    checks_ok,
    is_protected as contract_is_protected,
    load_contract,
    protected_policy,
    sha256_file,
    user_data_fingerprint,
    validate_release,
)

ROOT = Path(os.environ.get("MASTERMIND_INSTALL_ROOT") or os.environ.get("MASTERMIND_UPDATE_ROOT") or Path(__file__).resolve().parent).resolve()
UPDATES = ROOT / "updates"
INBOX = UPDATES / "inbox"
BACKUPS = UPDATES / "backups"
STATE = UPDATES / "state.json"
JOURNAL = UPDATES / "transaction.json"
_lock_depth = 0
_lock_handle = None


@contextmanager
def transaction_lock():
    global _lock_depth, _lock_handle
    if _lock_depth:
        _lock_depth += 1
        try:
            yield
        finally:
            _lock_depth -= 1
        return
    UPDATES.mkdir(parents=True, exist_ok=True)
    handle = (UPDATES / "update.lock").open("a+b")
    try:
        handle.seek(0, 2)
        if handle.tell() == 0:
            handle.write(b"0"); handle.flush()
        handle.seek(0)
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        handle.close()
        raise RuntimeError("Another update or recovery is in progress.")
    _lock_handle = handle; _lock_depth = 1
    try:
        yield
    finally:
        _lock_depth = 0; _lock_handle = None
        if os.name == "nt":
            import msvcrt
            handle.seek(0); msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()


def supervised_restart_allowed():
    token = os.environ.get("MASTERMIND_VERIFY_TOKEN", "")
    if not token or not JOURNAL.exists():
        return False
    j = json.loads(JOURNAL.read_text(encoding="utf-8"))
    if j.get("phase") != "VERIFYING_LIVE" or not secrets.compare_digest(str(j.get("token", "")), token):
        return False
    try:
        with transaction_lock():
            pass
    except RuntimeError:
        return True
    raise RuntimeError("Verification restart has no active Update Manager.")


# Permanent failsafe policy. The release contract may ADD protections, never remove these.
FAILSAFE_PROTECTED = {
    "data/settings.json",
    "data/custom_styles.json",
    "data/custom_style_bank.json",
    "data/custom_performance_lanes.json",
    "data/custom_song_deconstructions.json",
    "data/custom_concepts.json",
    "data/custom_project_dna.json",
}
FAILSAFE_PREFIXES = (
    "data/projects/",
    "data/custom_",
    "updates/backups/",
    "updates/inbox/",
)


def version_tuple(v: str):
    import re
    nums = re.findall(r"\d+", str(v or ""))
    return tuple(int(x) for x in nums[:4]) or (0,)


def current_version() -> str:
    try:
        return (ROOT / "VERSION.txt").read_text(encoding="utf-8").strip() or "0"
    except Exception:
        return "0"


def save_state(**kwargs):
    UPDATES.mkdir(parents=True, exist_ok=True)
    current = {}
    try:
        current = json.loads(STATE.read_text(encoding="utf-8"))
    except Exception:
        pass
    current.update(kwargs)
    current["updated_at"] = datetime.now().isoformat(timespec="seconds")
    tmp = STATE.with_suffix(".tmp")
    tmp.write_text(json.dumps(current, indent=2), encoding="utf-8")
    tmp.replace(STATE)


def save_journal(payload: dict):
    UPDATES.mkdir(parents=True, exist_ok=True)
    payload = dict(payload)
    payload["updated_at"] = datetime.now().isoformat(timespec="seconds")
    tmp = JOURNAL.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    tmp.replace(JOURNAL)


def clear_journal():
    JOURNAL.unlink(missing_ok=True)


def safe_rel(name: str) -> str:
    if not isinstance(name, str) or not name or ":" in name or "\x00" in name:
        raise RuntimeError(f"Unsafe path in update: {name}")
    p = PurePosixPath(name.replace("\\", "/"))
    if p.is_absolute() or ".." in p.parts:
        raise RuntimeError(f"Unsafe path in update: {name}")
    if str(p) in {".", ""} or any(part.endswith((".", " ")) for part in p.parts):
        raise RuntimeError(f"Unsafe path in update: {name}")
    return str(p)


def live_contract() -> dict:
    try:
        return load_contract(ROOT)
    except Exception:
        return {}


def is_protected(rel: str) -> bool:
    rel = rel.replace("\\", "/").lstrip("/").lower()
    if rel.endswith(".env") or rel.startswith("data/") and rel.split("/")[-1].startswith("custom_") or rel in FAILSAFE_PROTECTED or any(rel.startswith(p) for p in FAILSAFE_PREFIXES):
        return True
    contract = live_contract()
    try:
        return bool(contract and contract_is_protected(rel, contract))
    except Exception:
        return False


def locate_payload(zf: zipfile.ZipFile):
    names = [n for n in zf.namelist() if not n.endswith("/")]
    manifest_name = "manifest.json" if "manifest.json" in names else None
    if not manifest_name:
        raise RuntimeError("Verified update package is missing root manifest.json.")
    prefix = "payload/"
    if not any(n.startswith(prefix) for n in names):
        candidates = []
        for n in names:
            if "/payload/" in n:
                candidates.append(n.split("/payload/", 1)[0] + "/payload/")
        if candidates:
            prefix = sorted(candidates, key=len)[0]
    if not any(n.startswith(prefix) for n in names):
        raise RuntimeError("Update package has no payload folder.")
    return manifest_name, prefix


def read_manifest(zf: zipfile.ZipFile, manifest_name: str, prefix: str):
    manifest = json.loads(zf.read(manifest_name).decode("utf-8"))
    ver = str(manifest.get("version") or "").strip()
    if not ver:
        raise RuntimeError("Update manifest is missing a version.")
    files = manifest.get("files") or {}
    if isinstance(files, list):
        files = {str(x.get("path")): str(x.get("sha256") or "") for x in files if isinstance(x, dict) and x.get("path")}
    if not isinstance(files, dict) or not files:
        raise RuntimeError("Update manifest has no verified file list.")
    normalized = {}
    for rel_raw, digest in files.items():
        rel = safe_rel(rel_raw)
        digest = str(digest or "").strip().lower()
        if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
            raise RuntimeError(f"Update manifest is missing a valid SHA-256 for {rel}.")
        if rel.lower() in {x.lower() for x in normalized}:
            raise RuntimeError("Duplicate or case-aliased payload path")
        normalized[rel] = digest
    return manifest, normalized


def extract_verified(package: Path, stage: Path):
    with zipfile.ZipFile(package) as zf:
        manifest_name, prefix = locate_payload(zf)
        manifest, files = read_manifest(zf, manifest_name, prefix)
        extracted = []
        names = zf.namelist()
        if len(names) != len(set(names)):
            raise RuntimeError("Duplicate ZIP entries")
        for info in zf.infolist():
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise RuntimeError("Symlinks are not allowed in updates")
        for rel_raw, expected in files.items():
            rel = safe_rel(rel_raw)
            if is_protected(rel):
                raise RuntimeError(f"Update attempted to overwrite protected user data: {rel}")
            member = prefix + rel
            if member not in zf.namelist():
                raise RuntimeError(f"Manifest file missing from payload: {rel}")
            target = stage / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(member) as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            got = sha256_file(target)
            if got.lower() != expected.lower():
                raise RuntimeError(f"SHA-256 mismatch for {rel}")
            extracted.append(rel)
    return manifest, extracted


def validate_version_compatibility(manifest: dict, incoming_version: str, installed_version: str):
    if version_tuple(incoming_version) <= version_tuple(installed_version):
        raise RuntimeError(f"Refusing non-newer update v{incoming_version}; installed version is v{installed_version}.")
    min_v = str(manifest.get("from_version_min") or "").strip()
    max_v = str(manifest.get("from_version_max") or "").strip()
    if min_v and version_tuple(installed_version) < version_tuple(min_v):
        raise RuntimeError(f"Update v{incoming_version} requires at least v{min_v}; installed version is v{installed_version}.")
    if max_v and version_tuple(installed_version) > version_tuple(max_v):
        raise RuntimeError(f"Update v{incoming_version} supports through v{max_v}; installed version is v{installed_version}.")


def validate_incoming_contract(stage: Path, manifest: dict):
    contract_path = stage / CONTRACT_NAME
    if not contract_path.exists():
        raise RuntimeError(f"Update is missing required {CONTRACT_NAME}.")
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    if contract.get("contract_version") != 1:
        raise RuntimeError("Unsupported release-contract schema")
    required = {"app.py", "update_manager.py", "regression_check.py", "release_integrity.py", "runtime_probe.py", "static/index.html", "VERSION.txt"}
    programs = contract.get("program_files") or {}
    if not required.issubset(programs):
        raise RuntimeError("Release contract omits required program files")
    manifest_files = manifest.get("files") or {}
    if not isinstance(manifest_files, dict):
        raise RuntimeError("Release manifest must use a file/hash mapping")
    allowed = set(programs) | {CONTRACT_NAME} | set(contract.get("data_requirements") or {})
    if not set(manifest_files).issubset(allowed):
        raise RuntimeError("Payload contains files outside the declared release")
    if not required.issubset(manifest_files):
        raise RuntimeError("Payload omits required program files")
    for rel, digest in programs.items():
        if rel in manifest_files and manifest_files[rel] != digest:
            raise RuntimeError("Package manifest and release contract disagree: " + rel)
    mver = str(manifest.get("version") or "").strip().lstrip("vV")
    cver = str(contract.get("version") or "").strip().lstrip("vV")
    if cver != mver:
        raise RuntimeError(f"Release contract version v{cver or '?'} does not match package manifest v{mver or '?'}.")

    # New releases are not allowed to weaken existing user-data protections.
    old = live_contract()
    if old:
        old_exact, old_prefix = protected_policy(old)
        new_exact, new_prefix = protected_policy(contract)
        missing_exact = sorted(old_exact - new_exact)
        missing_prefix = sorted(set(old_prefix) - set(new_prefix))
        if missing_exact or missing_prefix:
            raise RuntimeError(f"Incoming release weakens user-data protection: exact={missing_exact}, prefixes={missing_prefix}")
    if int(contract.get("workspace_schema", -1)) != int((old or {}).get("workspace_schema", 4)):
        raise RuntimeError("Workspace schema migration requires a separately verified migration release.")
    return contract


def copy_tree_for_shadow(src: Path, dst: Path):
    ignore_names = {"updates", "__pycache__", ".git", ".pytest_cache"}
    for item in src.iterdir():
        if item.name in ignore_names:
            continue
        target = dst / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        elif item.is_file():
            shutil.copy2(item, target)


def overlay_stage(stage: Path, shadow: Path, files: list[str]):
    for rel in files:
        src = stage / rel
        dst = shadow / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def run_regression(root: Path):
    regression = root / "regression_check.py"
    if not regression.exists():
        raise RuntimeError("Release is missing regression_check.py.")
    proc = subprocess.run([sys.executable, str(regression)], cwd=str(root), capture_output=True, text=True, timeout=120)
    if proc.returncode != 0:
        tail = (proc.stdout + "\n" + proc.stderr)[-9000:]
        raise RuntimeError("Regression check failed:\n" + tail)


def validate_install_root(root: Path):
    app = root / "app.py"
    idx = root / "static" / "index.html"
    ver = root / "VERSION.txt"
    contract_path = root / CONTRACT_NAME
    if not app.exists() or not idx.exists() or not ver.exists() or not contract_path.exists():
        raise RuntimeError("Release validation failed: core program files or release contract are missing.")
    py_compile.compile(str(app), doraise=True)
    py_compile.compile(str(root / "update_manager.py"), doraise=True)
    py_compile.compile(str(root / "release_integrity.py"), doraise=True)
    for path in (root / "data").glob("*.json"):
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise RuntimeError(f"Release validation failed: invalid JSON in {path.name}: {exc}")
    checks = validate_release(root)
    ok, _warn = checks_ok(checks)
    if not ok:
        bad = [f"{c['name']}: {c['detail']}" for c in checks if not c.get("ok") and c.get("severity", "fail") == "fail"]
        raise RuntimeError("Release contract validation failed: " + " | ".join(bad[:8]))
    run_regression(root)


def validate_shadow(stage: Path, files: list[str], temp_root: Path):
    shadow = temp_root / "shadow_install"
    shadow.mkdir(parents=True, exist_ok=True)
    copy_tree_for_shadow(ROOT, shadow)
    overlay_stage(stage, shadow, files)
    validate_install_root(shadow)
    port = available_port(); token = secrets.token_hex(24)
    proc = launch_runtime(shadow, port, token, validation=True)
    try:
        verify_runtime(proc, shadow, port, str(load_contract(shadow)["version"]), token)
        run_regression(shadow)
    finally:
        stop_runtime(proc)
    return shadow


def backup_targets(files: list[str], backup_dir: Path):
    backed = []
    created = []
    for rel in files:
        src = ROOT / rel
        if src.exists() and src.is_file():
            dst = backup_dir / "program" / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            backed.append(rel)
        else:
            created.append(rel)
    return backed, created


def snapshot_user_data(backup_dir: Path, contract: dict):
    dest = backup_dir / "user_data_snapshot"
    dest.mkdir(parents=True, exist_ok=True)
    before = user_data_fingerprint(ROOT, contract)
    for rel in before:
        src = ROOT / rel
        dst = dest / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    (backup_dir / "user_data_fingerprint.json").write_text(json.dumps(before, indent=2), encoding="utf-8")
    return before


def restore_backup(backed: list[str], created: list[str], backup_dir: Path):
    for rel in backed:
        rel = safe_rel(rel)
        if not (backup_dir / "program" / rel).is_file():
            raise RuntimeError(f"Rollback backup is missing: {rel}")
    for rel in created:
        dst = ROOT / safe_rel(rel)
        if dst.is_file():
            dst.unlink()
    for rel in backed:
        src = backup_dir / "program" / safe_rel(rel)
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        tmp = dst.with_name(dst.name + ".rollback_ready")
        shutil.copy2(src, tmp); os.replace(tmp, dst)
        if sha256_file(src) != sha256_file(dst):
            raise RuntimeError(f"Rollback verification failed: {rel}")


def validate_restored_root():
    if (ROOT / CONTRACT_NAME).exists():
        validate_install_root(ROOT)
    else:
        # v1.9.6 and earlier have no release contract. Restored bytes are checked
        # against their backups above, then the legacy entry points are compiled.
        for name in ("app.py", "update_manager.py", "regression_check.py"):
            py_compile.compile(str(ROOT / name), doraise=True)
        if not (ROOT / "static/index.html").is_file():
            raise RuntimeError("Legacy rollback UI missing")


def prepare_commit(stage: Path, files: list[str]) -> dict[str, Path]:
    ready: dict[str, Path] = {}
    for rel in files:
        src = stage / rel
        dst = ROOT / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        tmp = dst.with_name(dst.name + ".update_ready")
        shutil.copy2(src, tmp)
        if sha256_file(tmp) != sha256_file(src):
            raise RuntimeError(f"Prepared update file failed verification: {rel}")
        ready[rel] = tmp
    return ready


def commit_prepared(ready: dict[str, Path], stage: Path, files: list[str], journal: dict):
    journal = dict(journal)
    journal["phase"] = "COMMITTING"
    journal["committed"] = []
    save_journal(journal)
    for rel in files:
        os.replace(ready[rel], ROOT / rel)
        journal["committed"].append(rel)
        save_journal(journal)
    for rel in files:
        if sha256_file(ROOT / rel) != sha256_file(stage / rel):
            raise RuntimeError(f"Post-commit hash verification failed: {rel}")


def cleanup_ready_files(files: list[str]):
    for rel in files:
        p = ROOT / rel
        tmp = p.with_name(p.name + ".update_ready")
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass


def recover_incomplete_transaction() -> bool:
    if not JOURNAL.exists():
        return False
    with transaction_lock():
        j = json.loads(JOURNAL.read_text(encoding="utf-8"))
        phase = str(j.get("phase") or "")
        if phase == "COMMITTED":
            clear_journal()
            return False
        if phase not in {"PREPARED", "COMMITTING", "VERIFYING_LIVE", "ROLLING_BACK"}:
            raise RuntimeError("Unrecognized update transaction phase; recovery required.")
        backup = Path(str(j.get("backup") or "")).resolve()
        if not backup.is_relative_to(BACKUPS.resolve()) or not backup.is_dir():
            raise RuntimeError("An incomplete update transaction exists but its rollback backup is missing or outside the backup folder.")
        backed = [safe_rel(str(x)) for x in (j.get("backed") or [])]
        created = [safe_rel(str(x)) for x in (j.get("created") or [])]
        save_state(status="RECOVERING", detail=f"Recovering incomplete transaction from phase {phase}")
        restore_backup(backed, created, backup)
        cleanup_ready_files([safe_rel(str(x)) for x in (j.get("files") or [])])
        validate_restored_root()
        clear_journal()
        save_state(status="RECOVERED", detail=f"Rolled back incomplete transaction from phase {phase}")
        return True


def restart_app():
    start = ROOT / "START_MASTERMIND.cmd"
    if os.name == "nt" and start.exists():
        subprocess.Popen(["cmd.exe", "/c", "start", "", str(start)], cwd=str(ROOT), creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
    else:
        subprocess.Popen([sys.executable, str(ROOT / "app.py")], cwd=str(ROOT), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def runtime_candidates():
    settings = {}
    try:
        settings = json.loads((ROOT / "data" / "settings.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    base = int(settings.get("port", 8765) or 8765)
    return [f"http://127.0.0.1:{p}" for p in range(base, base + 20)]


def verify_restarted_runtime(expected_version: str, timeout: float = 15.0):
    deadline = time.time() + timeout
    last = "no response"
    while time.time() < deadline:
        for base in runtime_candidates():
            try:
                with urllib.request.urlopen(base + "/api/health", timeout=0.75) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                if str(data.get("version") or "") == expected_version and data.get("release_contract_ok") is True:
                    return base, data
                last = f"{base} returned v{data.get('version')} contract_ok={data.get('release_contract_ok')}"
            except Exception as exc:
                last = str(exc)
        time.sleep(0.45)
    raise RuntimeError(f"Restarted runtime did not pass health verification: {last}")


def shutdown_runtime(base: str):
    try:
        req = urllib.request.Request(base + "/api/system/shutdown", data=b"{}", headers={"Content-Type": "application/json"}, method="POST")
        urllib.request.urlopen(req, timeout=2).read()
        time.sleep(0.5)
    except Exception:
        pass


def apply_update(package: Path, wait: float, restart: bool):
    with transaction_lock():
        return _apply_update_locked(package, wait, restart)


def _apply_update_locked(package: Path, wait: float, restart: bool):
    package = package.resolve()
    if not package.exists():
        raise RuntimeError(f"Update package not found: {package}")
    if package.suffix.lower() != ".zip":
        raise RuntimeError("Update package must be a .zip file.")
    if wait > 0:
        time.sleep(wait)

    recover_incomplete_transaction()

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup_dir = BACKUPS / stamp
    backup_dir.mkdir(parents=True, exist_ok=True)
    save_state(status="VERIFYING", package=package.name, backup=str(backup_dir))

    with tempfile.TemporaryDirectory(prefix="mastermind_update_", dir=str(UPDATES)) as td:
        temp_root = Path(td)
        stage = temp_root / "payload"
        stage.mkdir(parents=True, exist_ok=True)
        manifest, files = extract_verified(package, stage)
        if not files:
            raise RuntimeError("Update payload is empty.")
        incoming_version = str(manifest.get("version") or "").strip().lstrip("vV")
        installed_version = current_version().lstrip("vV")
        validate_version_compatibility(manifest, incoming_version, installed_version)
        incoming_contract = validate_incoming_contract(stage, manifest)

        # First prove the complete candidate in a shadow copy. Live files remain untouched here.
        save_state(status="STAGING", package=package.name, version=incoming_version, file_count=len(files))
        validate_shadow(stage, files, temp_root)

        # Snapshot user data and transaction targets before commit.
        before_user = snapshot_user_data(backup_dir, live_contract() or incoming_contract)
        backed, created = backup_targets(files, backup_dir)
        journal = {
            "phase": "PREPARED",
            "token": secrets.token_hex(24),
            "package": package.name,
            "from_version": installed_version,
            "to_version": incoming_version,
            "backup": str(backup_dir),
            "files": files,
            "backed": backed,
            "created": created,
        }
        save_journal(journal)
        runtime_proc = None
        try:
            ready = prepare_commit(stage, files)
            save_state(status="COMMITTING", package=package.name, version=incoming_version)
            commit_prepared(ready, stage, files, journal)
            save_journal({**journal, "phase": "VERIFYING_LIVE", "committed": files})
            validate_install_root(ROOT)

            # Protected user data must remain byte-for-byte unchanged during an update.
            after_user = user_data_fingerprint(ROOT, incoming_contract)
            changed_user = sorted(k for k in set(before_user) | set(after_user) if before_user.get(k) != after_user.get(k))
            if changed_user:
                raise RuntimeError(f"Protected user data changed during update: {changed_user[:8]}")

            runtime_base = None
            if restart:
                settings = {}
                try:
                    settings = json.loads((ROOT / "data/settings.json").read_text(encoding="utf-8"))
                except FileNotFoundError:
                    pass
                port = int(os.environ.get("MASTERMIND_LIVE_PORT") or settings.get("port", 8765))
                runtime_proc = launch_runtime(ROOT, port, journal["token"])
                runtime_base, _ = verify_runtime(runtime_proc, ROOT, port, incoming_version, journal["token"])
                # Recheck after actual startup, not only before it.
                if user_data_fingerprint(ROOT, incoming_contract) != before_user:
                    raise RuntimeError("Protected user data changed during update startup")
                run_regression(ROOT)

        except Exception:
            save_state(status="ROLLING_BACK", package=package.name)
            stop_runtime(runtime_proc)
            save_journal({**journal, "phase": "ROLLING_BACK", "committed": files})
            restore_backup(backed, created, backup_dir)
            cleanup_ready_files(files)
            validate_restored_root()
            clear_journal()
            if restart:
                restart_app()
            raise

        save_journal({**journal, "phase": "COMMITTED"})
        cleanup_ready_files(files)
        clear_journal()

    applied_dir = UPDATES / "applied"
    applied_dir.mkdir(parents=True, exist_ok=True)
    try:
        shutil.move(str(package), str(applied_dir / package.name))
    except Exception:
        pass
    save_state(status="SUCCESS", package=package.name, version=incoming_version, backup=str(backup_dir), release_contract="verified", runtime="verified" if restart else "not requested")


def main():
    if "--apply" in sys.argv:
        package = Path(sys.argv[sys.argv.index("--apply") + 1]).resolve()
        with zipfile.ZipFile(package) as z:
            atomic = "release_contract.json" in z.namelist() and json.loads(z.read("release_contract.json")).get("atomic_format") == "mastermind.atomic.v1"
        if atomic:
            args = [sys.executable, str(ROOT / "atomic_watchdog.py"), "--root", str(ROOT), "--mode", "apply", "--package", str(package)]
            if os.environ.get("MASTERMIND_LIVE_PORT"):
                args += ["--port", os.environ["MASTERMIND_LIVE_PORT"]]
            os.execv(sys.executable, args)
        raise RuntimeError("This installation requires an atomic release package; legacy file-copy updates are blocked.")
    ap = argparse.ArgumentParser(description="MasterMind transactional update manager")
    ap.add_argument("--apply", help="Path to update zip")
    ap.add_argument("--wait", type=float, default=0.0)
    ap.add_argument("--restart", action="store_true")
    ap.add_argument("--recover", action="store_true")
    args = ap.parse_args()
    try:
        if args.recover:
            recovered = recover_incomplete_transaction()
            print("Recovered incomplete MasterMind update." if recovered else "No incomplete MasterMind update found.")
            return
        if not args.apply:
            raise RuntimeError("Use --apply <update.zip> or --recover.")
        apply_update(Path(args.apply), max(0.0, args.wait), args.restart)
        print("MasterMind update completed successfully.")
    except Exception as exc:
        save_state(status="FAILED", error=str(exc), package=Path(args.apply).name if args.apply else "")
        print(f"MasterMind update FAILED: {exc}")
        if os.name == "nt":
            input("Press Enter to close this update window...")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
