"""Stable standard-library updater. Never loaded from an incoming release."""
from __future__ import annotations
import base64
import hashlib
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from contextlib import contextmanager
from pathlib import Path, PurePosixPath

CONTRACT = 'release_contract.json'
FORMAT = 'mastermind.atomic.v1'
BANKS = {'producer_bank.json','style_bank.json','blueprint_bank.json',
         'artist_dna.json','production_architectures.json','style_dna.json'}
REQUIRED = {'app.py','regression_check.py','release_integrity.py','runtime_probe.py',
            'update_manager.py','atomic_core.py','atomic_watchdog.py','static/index.html',
            'VERSION.txt','START_MASTERMIND.cmd'}
BOOTSTRAP_FILES = ('atomic_core.py','atomic_watchdog.py')


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def canonical(obj):
    return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_atomic(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.'+secrets.token_hex(6)+'.tmp')
    try:
        with tmp.open('xb') as f:
            f.write(canonical(obj));f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
        if os.name!='nt':
            fd=os.open(str(path.parent),os.O_RDONLY)
            try:os.fsync(fd)
            finally:os.close(fd)
    finally:
        tmp.unlink(missing_ok=True)


def safe_path(name):
    if not isinstance(name,str) or not name or '\\' in name or ':' in name or '\x00' in name:
        raise RuntimeError('Unsafe release path')
    p=PurePosixPath(name)
    reserved={'con','prn','aux','nul',*(f'com{i}' for i in range(1,10)),*(f'lpt{i}' for i in range(1,10))}
    if p.is_absolute() or '..' in p.parts or str(p)!=name or any(x.endswith(('.', ' ')) or x.split('.')[0].lower() in reserved for x in p.parts):
        raise RuntimeError('Unsafe release path: '+name)
    if p.parts[0].lower() in {'updates','releases','backups'} or name.lower().endswith('.env'):
        raise RuntimeError('Release attempts to include user/control data')
    if p.parts[0].lower()=='data' and (len(p.parts)!=2 or p.parts[1] not in BANKS):
        raise RuntimeError('Release attempts to overwrite protected user data')
    return name


def version(v):
    if not re.fullmatch(r'\d+\.\d+\.\d+',str(v)):
        raise RuntimeError('Invalid release version')
    return tuple(map(int,v.split('.')))


def validate_contract(c):
    if c.get('atomic_format')!=FORMAT or c.get('contract_version')!=1 or c.get('bootstrap_protocol')!=1:
        raise RuntimeError('Unsupported atomic release format')
    version(c.get('version'))
    files=c.get('program_files')
    if not isinstance(files,dict) or not REQUIRED.issubset(files):
        raise RuntimeError('Release omits required program files')
    if not {'data/'+x for x in BANKS}.issubset(files):
        raise RuntimeError('Atomic release must contain all built-in banks')
    seen=set()
    for name,h in files.items():
        safe_path(name)
        if name.lower() in seen or not re.fullmatch('[0-9a-f]{64}',str(h)):
            raise RuntimeError('Invalid or duplicate release hash entry')
        seen.add(name.lower())
    # This release intentionally has no user-data migration. Unknown changes fail
    # before touching the active pointer rather than silently converting projects.
    if c.get('workspace_schema')!=4 or c.get('migrations')!=[]:
        raise RuntimeError('Unsupported workspace migration; explicit migration implementation required')
    if not c.get('capabilities') or not c.get('browser_gates'):
        raise RuntimeError('Runtime/browser capability registry missing')
    if c.get('user_data_policy',{}).get('atomic_storage')!='external-data-directory':
        raise RuntimeError('Atomic user-data policy missing')
    return c


def verify_signature(document,trust_path,required=True):
    sig=document.get('signature')
    if not sig:
        if required:raise RuntimeError('Signed remote update required')
        return
    if sig.get('algorithm')!='rsa-sha256':raise RuntimeError('Unsupported signature algorithm')
    trust=read(trust_path)
    key=trust.get('keys',{}).get(sig.get('key_id'))
    if not key:raise RuntimeError('Update signing key is not trusted')
    n=int(key['n'],16);e=int(key.get('e',65537));size=(n.bit_length()+7)//8
    if n.bit_length()<2048 or e<3 or e%2==0:raise RuntimeError('Invalid trusted RSA key')
    raw=base64.b64decode(sig['value'],validate=True)
    if len(raw)!=size or int.from_bytes(raw,'big')>=n:raise RuntimeError('Invalid signature size')
    message={k:v for k,v in document.items() if k!='signature'}
    tail=bytes.fromhex('3031300d060960864801650304020105000420')+hashlib.sha256(canonical(message)).digest()
    expected=b'\x00\x01'+b'\xff'*(size-len(tail)-3)+b'\x00'+tail
    actual=pow(int.from_bytes(raw,'big'),e,n).to_bytes(size,'big')
    if not secrets.compare_digest(actual,expected):raise RuntimeError('Update signature verification failed')


def fingerprint(folder):
    folder=Path(folder);out={}
    if folder.exists():
        for p in sorted(folder.rglob('*')):
            if p.is_symlink():raise RuntimeError('User data contains a symlink; update stopped')
            if p.is_file():out[p.relative_to(folder).as_posix()]=digest(p)
    return out


def http(port,path,body=None,token='',timeout=3):
    req=urllib.request.Request(f'http://127.0.0.1:{port}'+path,
        data=None if body is None else json.dumps(body).encode(),
        headers={'Content-Type':'application/json','X-MasterMind-Control':token})
    with urllib.request.urlopen(req,timeout=timeout) as r:return json.load(r)


def free_port():
    with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]


def kill_child(proc):
    if proc and proc.poll() is None:
        if os.name=='nt':
            subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10)
        else:proc.terminate()
        try:proc.wait(timeout=5)
        except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)


class AtomicManager:
    def __init__(self,root):
        self.root=Path(root).resolve();self.updates=self.root/'updates'
        self.releases=self.root/'releases';self.active=self.updates/'active_release.json'
        self.journal=self.updates/'atomic_transaction.json';self.runtime=self.updates/'atomic_runtime.json'
        self.updates.mkdir(exist_ok=True);self.releases.mkdir(exist_ok=True)
        self.data=self.root/'data';self.locked=False;self.child=None

    @contextmanager
    def lock(self):
        if self.locked:raise RuntimeError('Nested updater lock')
        f=(self.updates/'atomic.lock').open('a+b')
        try:
            f.seek(0,2)
            if not f.tell():f.write(b'0');f.flush()
            f.seek(0)
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:
            f.close();raise RuntimeError('An atomic update or startup is already in progress')
        self.locked=True
        try:yield
        finally:
            self.locked=False
            if os.name=='nt':
                import msvcrt
                f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
            else:
                import fcntl
                fcntl.flock(f.fileno(),fcntl.LOCK_UN)
            f.close()

    def state(self,status,**kw):
        write_atomic(self.updates/'state.json',{'status':status,'updated_at':time.time(),**kw})

    def release_path(self,pointer):
        name=pointer.get('release','')
        if not re.fullmatch(r'v\d+\.\d+\.\d+-[0-9a-f]{16}',name):raise RuntimeError('Invalid active release pointer')
        p=self.releases/name
        if p.is_symlink() or not p.is_dir():raise RuntimeError('Active release directory is unavailable')
        if digest(p/CONTRACT)!=pointer.get('manifest_sha256'):raise RuntimeError('Active manifest hash mismatch')
        c=self.verify_tree(p)
        if c['version']!=pointer.get('version'):raise RuntimeError('Active release version mismatch')
        return p,c

    def verify_tree(self,path):
        path=Path(path);c=validate_contract(read(path/CONTRACT))
        expected=set(c['program_files'])|{CONTRACT}
        for p in path.rglob('*'):
            if p.is_symlink():raise RuntimeError('Release contains a symlink')
            if p.is_file() and p.relative_to(path).as_posix() not in expected:
                if '__pycache__' not in p.parts:raise RuntimeError('Untracked file in release: '+str(p))
        for rel,h in c['program_files'].items():
            if not (path/rel).is_file() or digest(path/rel)!=h:raise RuntimeError('Release hash mismatch: '+rel)
        if (path/'VERSION.txt').read_text().strip()!=c['version']:raise RuntimeError('Release version file mismatch')
        for rel in BOOTSTRAP_FILES:
            if digest(self.root/rel)!=c['program_files'][rel]:
                raise RuntimeError('Release requires a different watchdog bootstrap; use a separately verified bootstrap migration')
        return c

    def publish_directory(self,staged):
        c=self.verify_tree(staged);h=digest(staged/CONTRACT)
        name='v'+c['version']+'-'+h[:16];dest=self.releases/name
        if dest.exists():
            self.verify_tree(dest)
        else:os.replace(staged,dest)
        return {'release':name,'version':c['version'],'manifest_sha256':h}

    def ensure_layout(self):
        if self.active.exists():
            try:return self.release_path(read(self.active))
            except Exception:
                previous=self.updates/'previous_release.json'
                if not previous.exists():raise
                old=read(previous);release,c=self.release_path(old)
                self.stop_current();write_atomic(self.active,old)
                self.state('ROLLED_BACK',version=c['version'],detail='Active release failed startup hash verification')
                return release,c
        c=validate_contract(read(self.root/CONTRACT))
        with tempfile.TemporaryDirectory(prefix='.bootstrap-',dir=self.releases) as td:
            staged=Path(td)/'release';staged.mkdir()
            for rel,h in c['program_files'].items():
                src=self.root/rel
                if not src.is_file() or digest(src)!=h:raise RuntimeError('Installed bootstrap file mismatch: '+rel)
                dst=staged/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
            shutil.copy2(self.root/CONTRACT,staged/CONTRACT)
            pointer=self.publish_directory(staged)
            write_atomic(self.active,pointer)
        return self.release_path(pointer)

    def extract(self,package,staged):
        with zipfile.ZipFile(package) as z:
            names=z.namelist()
            if len(names)!=len(set(names)) or sum(x.file_size for x in z.infolist())>128*1024*1024:
                raise RuntimeError('Invalid or oversized atomic package')
            c=validate_contract(json.loads(z.read(CONTRACT)))
            verify_signature(c,self.data/'update_trust.json',required=False)
            expected={'payload/'+n for n in c['program_files']}
            actual={n for n in names if n.startswith('payload/') and not n.endswith('/')}
            if actual!=expected:raise RuntimeError('Atomic payload does not match its manifest')
            for rel in c['program_files']:
                info=z.getinfo('payload/'+rel)
                if (info.external_attr>>16)&0o170000==0o120000:raise RuntimeError('Symlink payload rejected')
                dst=staged/safe_path(rel);dst.parent.mkdir(parents=True,exist_ok=True)
                with z.open(info) as src,dst.open('xb') as out:shutil.copyfileobj(src,out)
            (staged/CONTRACT).write_bytes(canonical(c))
        return self.verify_tree(staged)

    def env(self,release,token,port,validation=False,data_root=None):
        env={k:v for k,v in os.environ.items() if not k.startswith('MASTERMIND_')}
        env.update(MASTERMIND_INSTALL_ROOT=str(self.root),MASTERMIND_DATA_ROOT=str(data_root or self.data),
            MASTERMIND_ATOMIC_CHILD='1',MASTERMIND_VERIFY_TOKEN=token,MASTERMIND_VERIFY_PORT=str(port),
            MASTERMIND_NO_BROWSER='1',PYTHONDONTWRITEBYTECODE='1')
        if validation:env['MASTERMIND_VALIDATION']='1';env.pop('OPENAI_API_KEY',None)
        return env

    def launch(self,release,port,validation=False,data_root=None):
        token=secrets.token_hex(24);env=self.env(release,token,port,validation,data_root)
        logdir=self.updates/'logs';logdir.mkdir(exist_ok=True)
        log=(logdir/('validation.log' if validation else 'runtime.log')).open('ab')
        try:proc=subprocess.Popen([sys.executable,'-B',str(release/'app.py')],cwd=release,env=env,stdout=log,stderr=log)
        finally:log.close()
        rec={'pid':proc.pid,'token':token,'port':port,'root':str(release),'version':read(release/CONTRACT)['version']}
        if not validation:write_atomic(self.runtime,rec)
        return proc,rec

    def health(self,rec):
        h=http(rec['port'],'/api/health')
        if (h.get('runtime_pid')!=rec['pid'] or h.get('runtime_token')!=rec['token']
            or Path(h.get('runtime_root','')).resolve()!=Path(rec['root']).resolve()
            or h.get('version')!=rec['version']):raise RuntimeError('Runtime identity mismatch')
        if h.get('ok') is not True:raise RuntimeError('Runtime integrity failed')
        return h

    def await_runtime(self,proc,rec):
        end=time.monotonic()+20;error='not ready'
        while time.monotonic()<end:
            if proc.poll() is not None:raise RuntimeError('Candidate server exited: '+str(proc.returncode))
            try:self.health(rec);return
            except Exception as e:error=str(e);time.sleep(.1)
        raise RuntimeError('Server readiness failed: '+error)

    def stop_current(self):
        if not self.runtime.exists():return
        rec=read(self.runtime)
        try:
            # Identity must match; failing health alone must not prevent stopping a
            # known damaged candidate before rollback.
            h=http(rec['port'],'/api/health')
        except (urllib.error.URLError,ConnectionError,TimeoutError):
            self.runtime.unlink(missing_ok=True);return
        if h.get('runtime_pid')!=rec['pid'] or h.get('runtime_token')!=rec['token']:
            raise RuntimeError('Refusing to stop a different localhost service')
        http(rec['port'],'/api/system/shutdown',{},rec['token'],timeout=20)
        end=time.monotonic()+10
        while time.monotonic()<end:
            try:http(rec['port'],'/api/health',timeout=.3)
            except (urllib.error.URLError,ConnectionError,TimeoutError):
                self.runtime.unlink(missing_ok=True);return
            time.sleep(.1)
        raise RuntimeError('Prior runtime did not stop; pointer unchanged')

    def browser_executable(self):
        configured=os.environ.get('MASTERMIND_TEST_BROWSER')
        candidates=[configured] if configured else []
        for var in ('PROGRAMFILES(X86)','PROGRAMFILES','LOCALAPPDATA'):
            base=os.environ.get(var)
            if base:
                candidates.extend(str(Path(base)/rel) for rel in ('Microsoft/Edge/Application/msedge.exe','Google/Chrome/Application/chrome.exe'))
        for name in ('msedge','google-chrome','chromium','chromium-browser'):
            p=shutil.which(name)
            if p:candidates.append(p)
        for p in candidates:
            if p and Path(p).is_file():return str(p)
        raise RuntimeError('Browser validation requires Microsoft Edge or Chrome installed on this computer')

    def browser_gate(self,rec,c):
        with tempfile.TemporaryDirectory(prefix='browser-check-',dir=self.updates) as td:
            args=[self.browser_executable(),'--headless=new','--disable-gpu','--no-first-run',
                '--no-default-browser-check','--disable-extensions','--disable-background-networking',
                '--remote-debugging-port=0','--user-data-dir='+td,
                f'http://127.0.0.1:{rec["port"]}/?atomic_test='+rec['token']]
            if os.name!='nt' and hasattr(os,'geteuid') and os.geteuid()==0:args+=['--no-sandbox','--disable-dev-shm-usage']
            proc=subprocess.Popen(args,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            try:
                end=time.monotonic()+35
                while time.monotonic()<end:
                    result=http(rec['port'],'/api/atomic/browser_result',token=rec['token'])
                    if result.get('complete'):
                        checks=result.get('checks',{})
                        failed=[name for name in c['browser_gates'] if checks.get(name) is not True]
                        if failed:raise RuntimeError('Browser regression failed: '+', '.join(failed)+' '+str(result.get('errors',[])))
                        return result
                    if proc.poll() is not None:raise RuntimeError('Validation browser exited before reporting')
                    time.sleep(.15)
                raise RuntimeError('Browser validation did not complete')
            finally:kill_child(proc)

    def test_running(self,release,proc,rec,env,require_browser=True):
        self.await_runtime(proc,rec)
        c=read(release/CONTRACT)
        result=http(rec['port'],'/api/system/selftest')
        if result.get('ok') is not True:raise RuntimeError('Running server self-test failed')
        boot=http(rec['port'],'/api/bootstrap')
        if boot.get('release_contract',{}).get('version')!=c['version']:raise RuntimeError('Bootstrap registry mismatch')
        if require_browser:self.browser_gate(rec,c)
        run=subprocess.run([sys.executable,'-B',str(release/'regression_check.py')],cwd=release,
            env=env,capture_output=True,text=True,timeout=90)
        if run.returncode:raise RuntimeError('Regression suite failed: '+(run.stdout+run.stderr)[-5000:])
        self.verify_tree(release)

    def record(self,j,phase):
        j['phase']=phase;write_atomic(self.journal,j);self.state(phase,version=(j.get('new') or {}).get('version'))

    def recover(self):
        if not self.journal.exists():return
        j=read(self.journal)
        phase=j.get('phase')
        if phase not in {'PREPARING','STAGED','PROMOTING','VERIFYING','ROLLING_BACK','COMMITTED'}:
            raise RuntimeError('Unknown atomic transaction phase; startup blocked')
        old=j.get('old')
        if phase=='COMMITTED':
            try:
                self.release_path(j['new'])
                if read(self.active)!=j['new']:raise RuntimeError('Committed pointer mismatch')
                self.journal.unlink();return
            except Exception:pass
        try:self.release_path(old)
        except Exception:
            backup=Path(j.get('backup','')).resolve()
            if not backup.is_relative_to((self.updates/'backups').resolve()):raise RuntimeError('Recovery backup path rejected')
            saved=backup/'program'
            if digest(saved/CONTRACT)!=old.get('manifest_sha256'):raise RuntimeError('Recovery backup manifest mismatch')
            self.verify_tree(saved)
            target=self.releases/old['release']
            self.stop_current()
            if target.exists():os.replace(target,self.releases/('quarantine-'+secrets.token_hex(8)))
            with tempfile.TemporaryDirectory(prefix='.restore-',dir=self.releases) as td:
                restored=Path(td)/'release';shutil.copytree(saved,restored);os.replace(restored,target)
            self.release_path(old)
        self.stop_current()
        write_atomic(self.active,old)
        self.journal.unlink()
        self.state('ROLLED_BACK',version=old['version'],detail='Recovered interrupted atomic update')

    def stage_validate(self,release,data_snapshot):
        proc,rec=self.launch(release,free_port(),validation=True,data_root=data_snapshot)
        try:self.test_running(release,proc,rec,self.env(release,rec['token'],rec['port'],True,data_snapshot))
        finally:kill_child(proc)

    def apply(self,package,port):
        with self.lock():
            self.recover();self.ensure_layout();old=read(self.active)
            _,oldc=self.release_path(old)
            stamp=str(time.time_ns());backup=self.updates/'backups'/('atomic-'+stamp)
            backup.mkdir(parents=True)
            j={'old':old,'new':None,'backup':str(backup),'package':Path(package).name,'token':secrets.token_hex(24)}
            self.record(j,'PREPARING')
            proc=None
            try:
                self.stop_current()
                before=fingerprint(self.data)
                shutil.copytree(self.data,backup/'data')
                write_atomic(backup/'data_hashes.json',before)
                write_atomic(backup/'previous_release.json',old)
                # The complete previous release is retained in releases/ and also
                # copied into the recovery backup for independent inspection.
                shutil.copytree(self.releases/old['release'],backup/'program')
                with tempfile.TemporaryDirectory(prefix='.stage-',dir=self.releases) as td:
                    staged=Path(td)/'release';staged.mkdir()
                    c=self.extract(package,staged)
                    if version(c['version'])<=version(old['version']):raise RuntimeError('Refusing non-newer atomic release')
                    if c.get('from_version_min') and version(old['version'])<version(c['from_version_min']):raise RuntimeError('Installed version is below supported update range')
                    if c.get('from_version_max') and version(old['version'])>version(c['from_version_max']):raise RuntimeError('Installed version is above supported update range')
                    oldpol=oldc['user_data_policy'];newpol=c['user_data_policy']
                    for k in ('protected_exact','protected_prefixes'):
                        if not set(oldpol.get(k,[])).issubset(newpol.get(k,[])):raise RuntimeError('Incoming release weakens user-data protections')
                    # No schema changes are declared in this release; validation
                    # already rejects unknown migrations rather than ignoring them.
                    snapshot=Path(td)/'data';shutil.copytree(backup/'data',snapshot)
                    self.stage_validate(staged,snapshot)
                    if fingerprint(self.data)!=before:raise RuntimeError('User data changed while staging')
                    j['new']=self.publish_directory(staged)
                    self.record(j,'STAGED')
                self.record(j,'PROMOTING')
                write_atomic(self.updates/'previous_release.json',old)
                write_atomic(self.active,j['new'])
                self.record(j,'VERIFYING')
                release,_=self.release_path(j['new'])
                proc,rec=self.launch(release,port)
                self.test_running(release,proc,rec,self.env(release,rec['token'],port))
                if fingerprint(self.data)!=before:raise RuntimeError('User data changed during live verification')
                self.record(j,'COMMITTED');self.journal.unlink()
                self.state('SUCCESS',version=c['version'],backup=str(backup),mode='atomic-pointer')
                applied=self.updates/'applied';applied.mkdir(exist_ok=True)
                try:shutil.move(str(package),str(applied/Path(package).name))
                except OSError:pass
                return proc,rec
            except Exception as exc:
                kill_child(proc)
                self.record(j,'ROLLING_BACK')
                self.stop_current();release,_=self.release_path(old)
                write_atomic(self.active,old)
                proc,rec=self.launch(release,port)
                try:
                    self.test_running(release,proc,rec,self.env(release,rec['token'],port),require_browser=False)
                    self.journal.unlink()
                    self.state('ROLLED_BACK',version=old['version'],error=str(exc),backup=str(backup))
                except Exception:
                    kill_child(proc)
                    self.state('RECOVERY_REQUIRED',error=str(exc),backup=str(backup));raise
                return proc,rec

    def serve(self,port):
        with self.lock():
            self.recover();release,c=self.ensure_layout()
            if self.runtime.exists():
                try:
                    rec=read(self.runtime);self.health(rec)
                    if Path(rec['root']).resolve()==release:return None,rec
                except (urllib.error.URLError,ConnectionError,TimeoutError):pass
                self.stop_current()
            proc,rec=self.launch(release,port)
            try:
                self.await_runtime(proc,rec)
                if http(port,'/api/system/selftest').get('ok') is not True:raise RuntimeError('Startup integrity failed')
                return proc,rec
            except Exception:
                kill_child(proc)
                prior=self.updates/'previous_release.json'
                if not prior.exists() or read(prior)==read(self.active):raise
                old=read(prior);release,c=self.release_path(old)
                write_atomic(self.active,old)
                proc,rec=self.launch(release,port)
                try:
                    self.await_runtime(proc,rec)
                    if http(port,'/api/system/selftest').get('ok') is not True:raise RuntimeError('Rollback startup integrity failed')
                except Exception:kill_child(proc);raise
                self.state('ROLLED_BACK',version=c['version'],detail='Active runtime failed startup')
                return proc,rec

    def supervise(self,proc,rec):
        if proc is None:return
        try:
            for retry in range(3):
                status=proc.wait()
                if status==0 or self.journal.exists():return
                with self.lock():
                    if self.journal.exists():return
                    release,c=self.release_path(read(self.active))
                    self.state('RESTARTING',version=c['version'],attempt=retry+1)
                    proc,rec=self.launch(release,rec['port']);self.await_runtime(proc,rec)
            self.state('STOPPED',error='Runtime repeatedly exited; restart limit reached')
            kill_child(proc)
        except KeyboardInterrupt:kill_child(proc)


def run_watchdog(root,mode,package=None,port=None):
    m=AtomicManager(root)
    settings=read(m.data/'settings.json') if (m.data/'settings.json').exists() else {}
    previous_port=read(m.runtime).get('port') if m.runtime.exists() else None
    port=int(port or previous_port or settings.get('port',8765))
    if mode=='apply':proc,rec=m.apply(Path(package).resolve(),port)
    elif mode=='takeover':
        with m.lock():m.stop_current()
        proc,rec=m.serve(port)
    else:proc,rec=m.serve(port)
    url='http://127.0.0.1:'+str(rec['port'])
    print('MasterMind '+rec['version']+' running at '+url,flush=True)
    if mode=='serve' and settings.get('open_browser_on_start',True):
        import webbrowser
        webbrowser.open(url)
    m.supervise(proc,rec)
