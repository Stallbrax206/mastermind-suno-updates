@echo off
setlocal
cd /d "%~dp0"
title MasterMind Suno Studio

where py >nul 2>nul
if not errorlevel 1 goto USE_PY

where python >nul 2>nul
if not errorlevel 1 goto USE_PYTHON

echo.
echo Python 3 was not found on this computer.
echo Install Python 3, then run START_MASTERMIND.cmd again.
echo.
pause
goto END

:USE_PY
py -3 app.py
goto END

:USE_PYTHON
python app.py

:END
endlocal
