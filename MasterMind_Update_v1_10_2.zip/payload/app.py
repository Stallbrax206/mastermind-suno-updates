from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import re
import shutil
import socket
import subprocess
import time
import zipfile
import xml.etree.ElementTree as ET
import sys
import threading
import tempfile
import urllib.error
import urllib.request
import webbrowser
from datetime import datetime
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from release_integrity import checks_ok as release_checks_ok, flatten_ui_spec, load_contract as load_release_contract, validate_release
from knowledge_manager import (KnowledgeError, PRESET_FORMAT, apply_and_save,
    identity as knowledge_identity, load_effective, validate_pack, write_json_atomic)

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
INSTALL_ROOT = Path(os.environ.get("MASTERMIND_INSTALL_ROOT") or ROOT).resolve()
DATA = Path(os.environ.get("MASTERMIND_DATA_ROOT") or INSTALL_ROOT / "data").resolve()
BUILTINS = ROOT / "data"
ATOMIC_BROWSER_REPORT = {"complete": False}
MUTATION_LOCK = threading.RLock()
PROJECTS = DATA / "projects"
SETTINGS_PATH = DATA / "settings.json"
CUSTOM_STYLES_PATH = DATA / "custom_styles.json"
CUSTOM_STYLE_BANK_PATH = DATA / "custom_style_bank.json"
CUSTOM_PERFORMANCE_LANES_PATH = DATA / "custom_performance_lanes.json"
CUSTOM_SONG_DECONSTRUCTIONS_PATH = DATA / "custom_song_deconstructions.json"
CUSTOM_CONCEPTS_PATH = DATA / "custom_concepts.json"
CUSTOM_PROJECT_DNA_PATH = DATA / "custom_project_dna.json"
VERSION_PATH = ROOT / "VERSION.txt"
UPDATES = INSTALL_ROOT / "updates"
UPDATE_INBOX = UPDATES / "inbox"
UPDATE_BACKUPS = UPDATES / "backups"
UPDATE_STATE_PATH = UPDATES / "state.json"
UPDATE_MANAGER_PATH = INSTALL_ROOT / "update_manager.py"
UPDATE_LAUNCH_PROCESS = None
RELEASE_CONTRACT_PATH = ROOT / "release_contract.json"
KNOWLEDGE_PACK_PATH = ROOT / "KNOWLEDGE_PACK.json"
KNOWLEDGE_SCHEMA_PATH = ROOT / "KNOWLEDGE_SCHEMA.md"
CUSTOM_KNOWLEDGE_PATH = DATA / "custom_knowledge_pack.json"
KNOWLEDGE_HISTORY_PATH = DATA / "custom_knowledge_patch_history.json"
UPDATE_TRUST_BOOTSTRAP_PATH = ROOT / "UPDATE_TRUST_BOOTSTRAP.json"
UPDATE_TRUST_PATH = DATA / "update_trust.json"
REMOTE_UPDATE_MANIFEST_URL = "https://raw.githubusercontent.com/Stallbrax206/mastermind-suno-updates/main/manifest.json"

for p in (STATIC, DATA, PROJECTS, UPDATES, UPDATE_INBOX, UPDATE_BACKUPS):
    p.mkdir(parents=True, exist_ok=True)


def app_version() -> str:
    try:
        text = VERSION_PATH.read_text(encoding="utf-8").strip()
        m = re.search(r"v?(\d+(?:\.\d+)+)", text, re.I)
        return m.group(1) if m else text or "1.8"
    except Exception:
        return "1.8"


APP_VERSION = app_version()


def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path: Path, payload) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def ensure_trusted_update_channel() -> None:
    """One-time trust bootstrap delivered by the manually installed release."""
    trust = load_json(UPDATE_TRUST_BOOTSTRAP_PATH, {})
    if trust.get("format") != "mastermind.update.trust.v1" or not trust.get("keys"):
        raise RuntimeError("Built-in update trust bootstrap is invalid")
    if UPDATE_TRUST_PATH.exists():
        current = load_json(UPDATE_TRUST_PATH, {})
        if current != trust:
            raise RuntimeError("Existing update trust differs from this release; refusing to overwrite it")
    else:
        write_json_atomic(UPDATE_TRUST_PATH, trust)
    settings = load_json(SETTINGS_PATH, {})
    if not str(settings.get("update_manifest_url") or "").strip():
        settings["update_manifest_url"] = REMOTE_UPDATE_MANIFEST_URL
        settings.setdefault("auto_apply_trusted_updates", False)
        save_json(SETTINGS_PATH, settings)


def start_trusted_update_channel_bootstrap() -> None:
    """Provision trust only after an atomic promotion is durably committed."""
    if os.environ.get("MASTERMIND_VALIDATION") == "1":
        return
    transaction = UPDATES / "atomic_transaction.json"
    if not (os.environ.get("MASTERMIND_ATOMIC_CHILD") and transaction.exists()):
        ensure_trusted_update_channel()
        return

    def worker():
        for _ in range(600):
            state = load_json(UPDATE_STATE_PATH, {})
            if not transaction.exists() and state.get("status") == "SUCCESS" and str(state.get("version")) == APP_VERSION:
                try:
                    ensure_trusted_update_channel()
                    print("Trusted signed update channel configured.")
                except Exception as exc:
                    print("Trusted update channel bootstrap failed:", exc)
                return
            time.sleep(0.25)
    threading.Thread(target=worker, daemon=True).start()


def effective_knowledge() -> dict:
    return load_effective(KNOWLEDGE_PACK_PATH, CUSTOM_KNOWLEDGE_PATH)


PRESET_COLLECTIONS = {
    "custom_styles": CUSTOM_STYLES_PATH,
    "custom_style_bank": CUSTOM_STYLE_BANK_PATH,
    "performance_lanes": CUSTOM_PERFORMANCE_LANES_PATH,
    "song_deconstructions": CUSTOM_SONG_DECONSTRUCTIONS_PATH,
    "concepts": CUSTOM_CONCEPTS_PATH,
    "project_dna": CUSTOM_PROJECT_DNA_PATH,
}


def export_presets() -> dict:
    projects = []
    for path in sorted(PROJECTS.glob("*.json")):
        item = load_json(path, {})
        if isinstance(item, dict):
            projects.append(item)
    return {
        "format": PRESET_FORMAT,
        "schema_version": 1,
        "exported_at": datetime.now().isoformat(timespec="seconds"),
        **{name: load_json(path, []) for name, path in PRESET_COLLECTIONS.items()},
        "projects": projects,
    }


def _preset_key(item: dict, collection: str) -> str:
    for key in ("id", "reference", "name"):
        if str(item.get(key) or "").strip():
            return key + ":" + re.sub(r"[^a-z0-9]+", " ", str(item[key]).lower()).strip()
    raise ValueError(f"{collection} entry requires id, reference, or name")


def import_presets(bundle) -> dict:
    if not isinstance(bundle, dict) or bundle.get("format") != PRESET_FORMAT or bundle.get("schema_version") != 1:
        raise ValueError("Preset import must use mastermind.presets.v1 schema version 1")
    allowed = {"format", "schema_version", "exported_at", "projects", *PRESET_COLLECTIONS}
    unknown = set(bundle) - allowed
    if unknown:
        raise ValueError("Unknown preset sections: " + ", ".join(sorted(unknown)))
    planned = {}
    changes = []
    for collection, path in PRESET_COLLECTIONS.items():
        incoming = bundle.get(collection, [])
        if not isinstance(incoming, list) or any(not isinstance(x, dict) for x in incoming):
            raise ValueError(f"{collection} must be an array of objects")
        incoming_keys = [_preset_key(x, collection) for x in incoming]
        if len(incoming_keys) != len(set(incoming_keys)):
            raise ValueError(f"Duplicate entries found in imported {collection}")
        existing = load_json(path, [])
        if not isinstance(existing, list):
            existing = []
        positions = {_preset_key(x, collection): i for i, x in enumerate(existing) if isinstance(x, dict)}
        merged = list(existing)
        for item, key in zip(incoming, incoming_keys):
            if key in positions:
                before = merged[positions[key]];merged[positions[key]] = item
                if before != item:
                    changes.append({"operation": "replace", "path": f"{collection}.{key}", "before": before, "after": item})
            else:
                positions[key] = len(merged);merged.append(item)
                changes.append({"operation": "add", "path": f"{collection}.{key}", "after": item})
        planned[path] = merged

    project_items = bundle.get("projects", [])
    if not isinstance(project_items, list) or any(not isinstance(x, dict) for x in project_items):
        raise ValueError("projects must be an array of project objects")
    project_names = [str(x.get("name") or "").strip() for x in project_items]
    if any(not x for x in project_names) or len({x.lower() for x in project_names}) != len(project_names):
        raise ValueError("Every imported project requires a unique name")
    project_writes = {}
    for item, name in zip(project_items, project_names):
        path = PROJECTS / f"{safe_slug(name)}.json"
        before = load_json(path, None) if path.exists() else None
        project_writes[path] = item
        if before != item:
            changes.append({"operation": "replace" if before is not None else "add", "path": f"projects.{name}", "before": before, "after": item})

    # Everything is validated before the first durable write. Existing files are
    # retained in memory so an incidental write failure can be rolled back.
    writes = {**planned, **project_writes}
    originals = {path: path.read_bytes() if path.exists() else None for path in writes}
    try:
        for path, value in writes.items():
            write_json_atomic(path, value)
    except Exception:
        for path, raw in originals.items():
            if raw is None:
                path.unlink(missing_ok=True)
            else:
                tmp = path.with_suffix(path.suffix + ".restore")
                tmp.write_bytes(raw);os.replace(tmp, path)
        raise
    return {"ok": True, "change_count": len(changes), "changes": changes}


def safe_slug(name: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9._ -]+", "", (name or "").strip())
    slug = re.sub(r"\s+", "_", slug).strip("._")
    return slug[:100] or "untitled_project"


PRODUCTION_REQUIRED = ("primary_engine", "rhythm", "drums", "bass", "relationship", "harmony", "texture", "density", "arrangement", "transitions", "vocal_space", "mix", "guardrail")
PERFORMANCE_REQUIRED = ("reference", "phrasing", "rhythmic_behavior", "dynamics", "articulation", "hook_behavior", "performance_overlay", "guardrail")
CONCEPT_REQUIRED = ("reference", "core_premise", "point_of_view", "central_tension", "stakes", "hook_function", "verse_1_job", "verse_2_job", "scene_logic", "emotional_arc", "originality_guardrail")
PROJECT_REQUIRED = ("reference", "project_premise", "sonic_spine", "production_evolution", "performance_arc", "concept_progression", "energy_curve", "tempo_strategy", "hook_strategy", "subject_distribution", "sequencing_logic", "project_overlay", "cohesion_guardrail", "originality_guardrail")


def _plain(value) -> bool:
    return isinstance(value, str) and bool(value.strip())


def production_missing(obj: dict) -> list[str]:
    if not isinstance(obj, dict):
        return list(PRODUCTION_REQUIRED)
    missing = [k for k in PRODUCTION_REQUIRED if not _plain(obj.get(k))]
    if not isinstance(obj.get("instrument_bias"), list) or not [x for x in obj.get("instrument_bias", []) if _plain(x)]:
        missing.append("instrument_bias")
    return missing


def performance_missing(obj: dict) -> list[str]:
    if not isinstance(obj, dict):
        return list(PERFORMANCE_REQUIRED)
    return [k for k in PERFORMANCE_REQUIRED if not _plain(obj.get(k))]


def concept_missing(obj: dict) -> list[str]:
    if not isinstance(obj, dict):
        return list(CONCEPT_REQUIRED)
    return [k for k in CONCEPT_REQUIRED if not _plain(obj.get(k))]


def project_missing(obj: dict) -> list[str]:
    if not isinstance(obj, dict):
        return list(PROJECT_REQUIRED) + ["routing_keywords", "track_roles"]
    missing = [k for k in PROJECT_REQUIRED if not _plain(obj.get(k))]
    if not isinstance(obj.get("routing_keywords"), list) or not [x for x in obj.get("routing_keywords", []) if _plain(x)]:
        missing.append("routing_keywords")
    if not isinstance(obj.get("track_roles"), list) or not [x for x in obj.get("track_roles", []) if _plain(x)]:
        missing.append("track_roles")
    return missing


def require_production_dna(obj: dict, label="Production DNA") -> dict:
    missing = production_missing(obj)
    if missing:
        raise RuntimeError(f"{label} is incomplete; missing: {', '.join(missing)}. MasterMind will not substitute generic production.")
    obj["mechanics_complete"] = True
    return obj


def require_performance_dna(obj: dict, label="Performance DNA") -> dict:
    missing = performance_missing(obj)
    if missing:
        raise RuntimeError(f"{label} is incomplete; missing: {', '.join(missing)}.")
    ref = str(obj.get("reference") or "").strip()
    overlay = str(obj.get("performance_overlay") or "").strip()
    # The Suno-facing overlay may describe transferable behavior but must not carry the named reference.
    if ref and len(ref) >= 4 and re.search(rf"\\b{re.escape(ref)}\\b", overlay, re.I):
        raise RuntimeError("Performance overlay still contains the reference artist/name. Re-decode it as transferable performance mechanics before applying.")
    return obj


def require_concept_dna(obj: dict, label="Concept DNA") -> dict:
    missing = concept_missing(obj)
    if missing:
        raise RuntimeError(f"{label} is incomplete; missing: {', '.join(missing)}.")
    return obj


def require_project_dna(obj: dict, label="Project DNA") -> dict:
    missing = project_missing(obj)
    if missing:
        raise RuntimeError(f"{label} is incomplete; missing: {', '.join(missing)}.")
    ref = str(obj.get("reference") or "").strip()
    overlay = str(obj.get("project_overlay") or "").strip()
    if str(obj.get("source_type") or "").upper() == "REFERENCE" and ref and len(ref) >= 4 and re.search(rf"\b{re.escape(ref)}\b", overlay, re.I):
        raise RuntimeError("Project overlay still contains the reference project/name. Re-deconstruct it into transferable project mechanics before applying.")
    return obj


def _fingerprint_duplicates(items, key="mechanical_fingerprint"):
    seen = {}
    dupes = []
    for item in items if isinstance(items, list) else []:
        if not isinstance(item, dict):
            continue
        fp = str(item.get(key) or "").strip().lower()
        if not fp:
            continue
        label = str(item.get("reference") or item.get("name") or item.get("id") or "unknown")
        if fp in seen:
            dupes.append((seen[fp], label))
        else:
            seen[fp] = label
    return dupes


def system_selftest(client_ui_report=None) -> dict:
    checks = []
    requirements = load_release_contract(ROOT)["data_requirements"]
    def minimum(name):
        return int(requirements["data/" + name]["min_count"])
    def add(name, ok, detail, severity="fail"):
        checks.append({"name": name, "ok": bool(ok), "detail": str(detail), "severity": severity})

    try:
        knowledge = effective_knowledge()
        knowledge_errors = validate_pack(knowledge)
    except Exception as exc:
        knowledge = {"presets": {}, "recipes": {}}
        knowledge_errors = [str(exc)]
    add("Knowledge pack validation", not knowledge_errors, "single knowledge block valid" if not knowledge_errors else "; ".join(knowledge_errors[:8]))
    presets = knowledge.get("presets", {})
    recipes = knowledge.get("recipes", {})
    producers = presets.get("producers", [])
    styles = presets.get("styles", [])
    blueprints = presets.get("blueprints", [])
    artists = presets.get("artists", {})
    arch = recipes.get("production_architectures", [])

    add("Producer bank count", isinstance(producers, list) and len(producers) >= minimum("producer_bank.json"), f"{len(producers) if isinstance(producers,list) else 0} entries")
    bad_p = []
    for x in producers if isinstance(producers, list) else []:
        miss = production_missing(x)
        if miss:
            bad_p.append(f"{x.get('reference','?')}: {','.join(miss)}")
    add("Producer DNA completeness", not bad_p, "all complete" if not bad_p else "; ".join(bad_p[:5]))
    producer_refs = {str(x.get("reference") or "") for x in producers if isinstance(x, dict)}
    expected_new = {"Southside", "Wheezy", "Rogét Chahayed", "FnZ", "b4u", "G. Ry", "DJ Dahi"}
    add("2026 producer additions present", expected_new.issubset(producer_refs), ", ".join(sorted(expected_new - producer_refs)) or "all present")
    dup_prod = _fingerprint_duplicates(producers)
    add("Producer fingerprint uniqueness", not dup_prod, "no exact duplicate fingerprints" if not dup_prod else str(dup_prod[:5]), severity="warn")

    add("Style bank count", isinstance(styles, list) and len(styles) >= minimum("style_bank.json"), f"{len(styles) if isinstance(styles,list) else 0} entries")
    bad_s = []
    for x in styles if isinstance(styles, list) else []:
        miss = production_missing({**x, "rhythm": x.get("rhythm") or x.get("groove")})
        if miss:
            bad_s.append(f"{x.get('name','?')}: {','.join(miss)}")
    add("Style DNA completeness", not bad_s, "all complete" if not bad_s else "; ".join(bad_s[:5]))

    add("Blueprint bank count", isinstance(blueprints, list) and len(blueprints) >= minimum("blueprint_bank.json"), f"{len(blueprints) if isinstance(blueprints,list) else 0} entries")
    bad_b = []
    for x in blueprints if isinstance(blueprints, list) else []:
        probe = {**x, "rhythm": x.get("rhythm") or x.get("groove"), "instrument_bias": x.get("instrument_bias") or ([x.get("instruments")] if x.get("instruments") else [])}
        miss = production_missing(probe)
        if miss:
            bad_b.append(f"{x.get('name','?')}: {','.join(miss)}")
    add("Blueprint completeness", not bad_b, "all complete" if not bad_b else "; ".join(bad_b[:5]))

    dup_style = _fingerprint_duplicates(styles)
    dup_blue = _fingerprint_duplicates(blueprints)
    add("Style fingerprint uniqueness", not dup_style, "no exact duplicate fingerprints" if not dup_style else str(dup_style[:5]), severity="warn")
    add("Blueprint fingerprint uniqueness", not dup_blue, "no exact duplicate fingerprints" if not dup_blue else str(dup_blue[:5]), severity="warn")
    add("Artist locks", isinstance(artists, dict) and len(artists) >= minimum("artist_dna.json"), f"{len(artists) if isinstance(artists,dict) else 0} artist DNAs")
    add("Production architectures", isinstance(arch, list) and len(arch) >= minimum("production_architectures.json"), f"{len(arch) if isinstance(arch,list) else 0} architectures")
    project_items = load_json(CUSTOM_PROJECT_DNA_PATH, [])
    bad_projects = []
    for x in project_items if isinstance(project_items, list) else []:
        miss = project_missing(x)
        if miss:
            bad_projects.append(f"{x.get('reference','?')}: {','.join(miss)}")
    add("Saved Project DNA integrity", not bad_projects, f"{len(project_items) if isinstance(project_items,list) else 0} saved; all complete" if not bad_projects else "; ".join(bad_projects[:5]))
    add("Update manager", UPDATE_MANAGER_PATH.exists(), "installed" if UPDATE_MANAGER_PATH.exists() else "missing")
    add("Startup script", (INSTALL_ROOT / "START_MASTERMIND.cmd").exists(), "installed" if (INSTALL_ROOT / "START_MASTERMIND.cmd").exists() else "missing")
    # Shared release contract checks are the single source of truth for UI/version/schema coherence.
    # When invoked from the browser, client_ui_report verifies the page the user is ACTUALLY running.
    for rc in validate_release(ROOT, client_ui_report=client_ui_report):
        add("Release: " + str(rc.get("name") or "check"), rc.get("ok"), rc.get("detail"), rc.get("severity", "fail"))
    if os.environ.get("MASTERMIND_ATOMIC_CHILD") and os.environ.get("MASTERMIND_VALIDATION") != "1":
        try:
            pointer = json.loads((UPDATES / "active_release.json").read_text(encoding="utf-8"))
            selected = (INSTALL_ROOT / "releases" / pointer["release"]).resolve()
            add("Atomic release selection", selected == ROOT and pointer["version"] == APP_VERSION, "whole-release pointer matches the running server")
            add("External user-data isolation", not DATA.is_relative_to(ROOT), "projects/settings/custom data are outside the selected release")
            contract = load_release_contract(ROOT)
            guard_ok = all(hashlib.sha256((INSTALL_ROOT / name).read_bytes()).hexdigest() == contract["program_files"][name] for name in ("atomic_core.py", "atomic_watchdog.py"))
            add("Independent watchdog integrity", guard_ok, "stable watchdog files match this release contract")
        except Exception as exc:
            add("Atomic runtime integrity", False, exc)
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("mastermind_update_manager_integrity", UPDATE_MANAGER_PATH)
        updater_mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(updater_mod)
        project_protected = bool(updater_mod.is_protected("data/custom_project_dna.json"))
        future_custom_protected = bool(updater_mod.is_protected("data/custom_future_module.json"))
        add("Project DNA update protection", project_protected, "protected" if project_protected else "NOT protected")
        add("Future custom-data update protection", future_custom_protected, "protected by custom-data guard" if future_custom_protected else "NOT protected")
    except Exception as exc:
        add("Project DNA update protection", False, exc)
        add("Future custom-data update protection", False, exc)

    trust = load_json(UPDATE_TRUST_PATH, {})
    configured_url = str(load_json(SETTINGS_PATH, {}).get("update_manifest_url") or "")
    trust_deferred = os.environ.get("MASTERMIND_VALIDATION") == "1" or (UPDATES / "atomic_transaction.json").exists()
    add("Trusted update signing key", trust == load_json(UPDATE_TRUST_BOOTSTRAP_PATH, {}),
        "production public key installed" if trust == load_json(UPDATE_TRUST_BOOTSTRAP_PATH, {}) else "provisioning after atomic commit",
        severity="warn" if trust_deferred else "fail")
    add("Trusted update manifest", configured_url == REMOTE_UPDATE_MANIFEST_URL,
        "official signed feed configured" if configured_url == REMOTE_UPDATE_MANIFEST_URL else "provisioning after atomic commit",
        severity="warn" if trust_deferred else "fail")

    # User-data write test without touching real records.
    try:
        with tempfile.NamedTemporaryFile(prefix=".mastermind_probe_", dir=DATA, delete=True) as probe:
            probe.write(b"ok"); probe.flush()
        add("User-data write access", True, "writable")
    except Exception as exc:
        add("User-data write access", False, exc)

    fails = [c for c in checks if not c["ok"] and c["severity"] == "fail"]
    warns = [c for c in checks if not c["ok"] and c["severity"] == "warn"]
    return {"ok": not fails, "status": "PASS" if not fails and not warns else ("PASS WITH WARNINGS" if not fails else "FAIL"), "version": APP_VERSION, "checks": checks}


def _version_tuple(v: str):
    nums = re.findall(r"\d+", str(v or ""))
    return tuple(int(x) for x in nums[:4]) or (0,)


def launch_atomic_update(target, port=None):
    """Launch the stable watchdog directly with argument-safe subprocess APIs."""
    global UPDATE_LAUNCH_PROCESS
    from atomic_core import write_atomic
    with MUTATION_LOCK:
        if UPDATE_LAUNCH_PROCESS is not None and UPDATE_LAUNCH_PROCESS.poll() is None:
            raise RuntimeError("An update is already running. Check its status before retrying.")
        if (UPDATES / "atomic_transaction.json").exists():
            raise RuntimeError("An atomic update transaction is already in progress.")
        watchdog = INSTALL_ROOT / "atomic_watchdog.py"
        if not watchdog.is_file():
            raise RuntimeError("The independent update watchdog is missing.")
        launch_id = str(time.time_ns())
        log_path = UPDATES / "logs" / ("update-launch-" + launch_id + ".log")
        log_path.parent.mkdir(parents=True, exist_ok=True)
        state = {"status": "LAUNCHING", "package": target.name, "launch_id": launch_id,
                 "started_at": datetime.now().isoformat(timespec="seconds"),
                 "from_version": APP_VERSION, "log": str(log_path.relative_to(INSTALL_ROOT))}
        args = [sys.executable, str(watchdog), "--root", str(INSTALL_ROOT),
                "--mode", "apply", "--package", str(target.resolve())]
        if port is not None:
            args += ["--port", str(port)]
        # A runtime's identity and validation flags must not become the updater's.
        env = {k: v for k, v in os.environ.items() if not k.startswith("MASTERMIND_")}
        kwargs = {"cwd": str(INSTALL_ROOT), "env": env, "stdin": subprocess.DEVNULL}
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        write_atomic(UPDATE_STATE_PATH, state)
        try:
            with log_path.open("ab") as log:
                proc = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, **kwargs)
            UPDATE_LAUNCH_PROCESS = proc
        except Exception as exc:
            write_atomic(UPDATE_STATE_PATH, {**state, "status": "LAUNCH_FAILED", "error": str(exc)})
            raise RuntimeError("Update launch failed: " + str(exc)) from exc

        def report_early_exit():
            code = proc.wait()
            with MUTATION_LOCK:
                current = load_json(UPDATE_STATE_PATH, {})
                if current.get("launch_id") == launch_id and current.get("status") == "LAUNCHING":
                    try:
                        detail = log_path.read_text(encoding="utf-8", errors="replace")[-3000:].strip()
                    except OSError:
                        detail = ""
                    write_atomic(UPDATE_STATE_PATH, {**state, "status": "LAUNCH_FAILED",
                        "error": detail or f"Update watchdog exited before starting (exit {code}).",
                        "exit_code": code})
        threading.Thread(target=report_early_exit, daemon=True).start()
        return state


def pending_updates():
    out = []
    for z in sorted(UPDATE_INBOX.glob("*.zip"), key=lambda x: x.stat().st_mtime, reverse=True):
        info = {"filename": z.name, "size": z.stat().st_size, "version": "unknown"}
        try:
            with zipfile.ZipFile(z) as zf:
                manifest_name = "release_contract.json" if "release_contract.json" in zf.namelist() else "manifest.json"
                if manifest_name in zf.namelist():
                    m = json.loads(zf.read(manifest_name).decode("utf-8"))
                    info.update({"version": str(m.get("version") or "unknown"), "name": str(m.get("name") or z.stem)})
        except Exception as exc:
            info["error"] = str(exc)
        out.append(info)
    return out


def update_status():
    state = load_json(UPDATE_STATE_PATH, {})
    settings = load_json(SETTINGS_PATH, {})
    return {
        "version": APP_VERSION,
        "pending": pending_updates(),
        "manifest_url": settings.get("update_manifest_url", ""),
        "auto_apply": bool(settings.get("auto_apply_trusted_updates", False)),
        "last_state": state,
    }


def check_remote_update(download=True):
    settings = load_json(SETTINGS_PATH, {})
    url = str(settings.get("update_manifest_url") or "").strip()
    if not url:
        return {"ok": True, "configured": False, "message": "No trusted remote manifest configured. Local inbox is ready.", "pending": pending_updates()}
    if not url.lower().startswith("https://"):
        raise RuntimeError("Update manifest URL must use HTTPS.")
    req = urllib.request.Request(url, headers={"User-Agent": f"MasterMind-Suno-Studio/{APP_VERSION}"})
    with urllib.request.urlopen(req, timeout=20) as resp:
        manifest = json.loads(resp.read().decode("utf-8"))
    from atomic_core import verify_signature
    verify_signature(manifest, DATA / "update_trust.json", required=True)
    ver = str(manifest.get("version") or "").strip()
    dl = str(manifest.get("download_url") or "").strip()
    sha = str(manifest.get("sha256") or "").strip().lower()
    if not ver or not dl or not sha:
        raise RuntimeError("Remote update manifest is missing version, download_url, or sha256.")
    newer = _version_tuple(ver) > _version_tuple(APP_VERSION)
    result = {"ok": True, "configured": True, "current_version": APP_VERSION, "remote_version": ver, "newer": newer, "manifest": manifest}
    if newer and download:
        if not dl.lower().startswith("https://"):
            raise RuntimeError("Update download URL must use HTTPS.")
        target = UPDATE_INBOX / f"MasterMind_Update_v{safe_slug(ver)}.zip"
        with urllib.request.urlopen(dl, timeout=120) as resp, target.open("wb") as f:
            shutil.copyfileobj(resp, f)
        digest = hashlib.sha256(target.read_bytes()).hexdigest().lower()
        if digest != sha:
            target.unlink(missing_ok=True)
            raise RuntimeError("Downloaded update failed SHA-256 verification.")
        try:
            with zipfile.ZipFile(target) as package:
                signed_release = json.loads(package.read("release_contract.json"))
            verify_signature(signed_release, DATA / "update_trust.json", required=True)
            if signed_release.get("version") != ver:
                raise RuntimeError("Remote release version mismatch")
        except Exception:
            target.unlink(missing_ok=True)
            raise
        result["downloaded"] = target.name
    result["pending"] = pending_updates()
    return result


def bootstrap_payload():
    settings = load_json(SETTINGS_PATH, {})
    knowledge = effective_knowledge()
    presets = knowledge["presets"]
    recipes = knowledge["recipes"]
    projects = []
    for p in sorted(PROJECTS.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True):
        try:
            obj = load_json(p, {})
            projects.append({
                "name": obj.get("name", p.stem),
                "file": p.name,
                "updated_at": obj.get("updated_at", ""),
            })
        except Exception:
            pass
    return {
        "knowledge": knowledge,
        "artists": presets["artists"],
        "architectures": recipes["production_architectures"],
        "styles": presets["style_shortcuts"] + load_json(CUSTOM_STYLES_PATH, []),
        "producers": presets["producers"],
        "style_bank": presets["styles"] + load_json(CUSTOM_STYLE_BANK_PATH, []),
        "blueprints": presets["blueprints"],
        "performance_lanes": load_json(CUSTOM_PERFORMANCE_LANES_PATH, []),
        "song_deconstructions": load_json(CUSTOM_SONG_DECONSTRUCTIONS_PATH, []),
        "concepts": load_json(CUSTOM_CONCEPTS_PATH, []),
        "project_dna": load_json(CUSTOM_PROJECT_DNA_PATH, []),
        "settings": settings,
        "projects": projects,
        "ai": {
            "configured": bool(os.environ.get("OPENAI_API_KEY")),
            "model": settings.get("ai_model", "gpt-5.6-terra"),
        },
        "version": APP_VERSION,
        "release_contract": (lambda c: {"version": c.get("version"), "workspace_schema": c.get("workspace_schema"), "browser_gates": c.get("browser_gates", []), "contract_version": c.get("contract_version"), "ui_spec": flatten_ui_spec(c), "capability_ids": list((c.get("capabilities") or {}).keys())})(load_release_contract(ROOT)),
        "update": update_status(),
    }


def extract_response_text(obj: dict) -> str:
    chunks = []
    for item in obj.get("output", []) or []:
        if item.get("type") != "message":
            continue
        for part in item.get("content", []) or []:
            if part.get("type") in ("output_text", "text") and part.get("text"):
                chunks.append(part["text"])
    if chunks:
        return "\n".join(chunks).strip()
    return str(obj.get("output_text") or "").strip()


def openai_response(instructions: str, user_input: str, *, use_web: bool = False) -> str:
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is not configured. Run SET_OPENAI_KEY.cmd, then restart MasterMind.")
    settings = load_json(SETTINGS_PATH, {})
    model = settings.get("ai_model", "gpt-5.6-terra")
    payload = {
        "model": model,
        "instructions": instructions,
        "input": user_input,
    }
    if use_web:
        payload["tools"] = [{"type": "web_search"}]
    req = urllib.request.Request(
        "https://api.openai.com/v1/responses",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            obj = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        raise RuntimeError(f"AI request failed ({e.code}): {body[:1000]}") from e
    except Exception as e:
        raise RuntimeError(f"AI request failed: {e}") from e
    text = extract_response_text(obj)
    if not text:
        raise RuntimeError("AI response did not contain usable text.")
    return text


LYRIC_SYSTEM = """You are the Lyric Maker inside MasterMind Suno Studio.
Write complete, original song lyrics from the supplied artist DNA and creative brief.
The user's quality floor is fifth-draft minimum: no placeholder bars, no generic empowerment/grind filler, no fake scenes unless requested, no explaining the persona, and no concept-title leakage into lyrics.
Use natural human speech, believable cultural/social behavior, quotable turns, rhythmic phrasing, and concrete detail when appropriate.
Honor the artist's locked voice/persona. Production references may influence rhythmic writing but must never redesign the singer.
Keep section labels clear. Do not include analysis before or after the lyrics unless the brief explicitly requests it.
"""

ANALYZE_SYSTEM = """You are the Record Analyzer inside MasterMind Suno Studio.
Analyze the supplied full lyric as a producer would. Go beyond BPM/drums/bass. Read intensity, playfulness, sensuality, street weight, reflection, confidence, social energy, tension, warmth, conversational looseness, hookability, lyric density, section contrast, culture/social posture, call-and-response potential, instrumentation implications, harmonic behavior, arrangement behavior, and mix attitude.
Culture must be inferred from the actual language/social behavior and artist DNA, never from one slang word or stereotype.
Return concise JSON only, with numeric 0-10 fields: intensity, playful, sensual, street, reflective, confidence, social, tension, warmth, conversational, density, hookability, section_contrast. Also return strings: attitude, culture_read, instrument_direction, harmony_direction, arrangement_direction, mix_direction, recommended_architecture_id. recommended_architecture_id must be one of: stomp_independent, rolling_anchored, stomp_melodic, percussion_heavy, sliding_independent, pressure_build.
"""

STYLE_SYSTEM = """You are the free-text Style Decoder inside MasterMind Suno Studio.
The local reference bank is NOT your limit. Decode any producer, artist-production era, album-era, song-production reference, regional production movement, genre/subgenre, or clearly described blend supplied by the user. If web search is enabled and the reference is unfamiliar, ambiguous, contemporary, or era-specific, research it before decoding.

Translate the reference into TRANSFERABLE PRODUCTION MECHANICS that can be combined with a different singer/rapper without changing that artist's identity. Go deeper than drums and bass. Mood adjectives such as ominous, menacing, cinematic, luxurious, dark, aggressive, seductive, eerie, or triumphant are not sufficient instructions. Convert them into observable musical behavior: register, intervals, sustain, transient shape, rhythmic density, instrument role, harmonic rhythm, section change, stereo behavior, and low-end movement. Explicitly determine: perceived tempo/pocket; movement owner; kick/snare/clap behavior; hat/percussion behavior; bass/808 role; harmonic language and harmonic rhythm; instrument families and register use; texture/ear-candy philosophy; density and negative space; arrangement development; transition behavior; vocal-space strategy; and mix attitude.

If the user names multiple references, do not average them vaguely. Assign clear jobs when possible (for example: one reference for drums, another for low end, another for melodic texture) and describe the coherent resulting grammar. If the reference has materially different eras and the user did not specify one, identify that ambiguity in era and produce a useful general decode rather than pretending all eras are the same.

Do not reproduce a copyrighted melody, lyric, sample, distinctive composition, or a one-to-one recreation of a released beat. Do not merely repeat '[artist] style'. Producer/artist names are analysis labels only and should not be required in the final Suno-facing style prompt.

Return concise JSON only with: reference, era, primary_engine, traits (array), instrument_bias (array), rhythm, drums, bass, relationship, harmony, texture, density, arrangement, transitions, vocal_space, mix, guardrail, confidence_note. primary_engine must name the dominant musical carrier in concrete terms (for example: audible chopped/re-pitched record-sample loop, drum-led pocket, bass-led movement, guitar-led motif, piano-led motif) and state whether it must remain audible through the record. If the user explicitly asks that a source mechanic be primary, preserve that request here instead of averaging it away. IMPORTANT SCHEMA RULE: traits and instrument_bias must be arrays of plain strings. Every other field listed above must be a single plain human-readable string, not a nested object, array, or sub-dictionary. Put detailed subcomponents inside that string separated by semicolons.
"""

LEGACY_STYLE_SYSTEM = """You are the Legacy Style Translator inside MasterMind Suno Studio.
The user supplies an OLD Suno STYLE prompt that may use vague mood words, mixed formatting, shorthand, producer-era language, or older prompt habits. Translate it into the current MasterMind mechanics-first production DNA WITHOUT erasing what made the old style work.

Preserve Character is a numeric percentage from 0 to 100. At 90-100, keep the old BPM, pocket, instrument family, drum/bass roles, arrangement logic and mix character unless the prompt is internally contradictory. At 65-89, clarify and modernize the mechanics while preserving the recognizable identity. At 35-64, repair weak or vague construction but retain the most distinctive musical traits. Below 35, modernization may be more aggressive, but still do not replace the source with generic R&B/rap defaults.

Translate loaded adjectives such as dark, ominous, cinematic, luxurious, aggressive, seductive, emotional, atmospheric or futuristic into audible mechanics: register, sustain, interval choice, transient behavior, density, harmonic rhythm, instrument role, section change, stereo behavior, and low-end movement. Do not merely delete the old wording; preserve the intended musical character in mechanical form.

Identify the dominant Primary Engine. It may be sample-first, drum-machine-led, keyboard-led, guitar/pluck-led, bass-led, piano-led, percussion-led, synth-led, live-rhythm-section-led, or another concrete musical carrier. If the old prompt clearly says what drives the record, preserve that.

Do not imitate or reproduce a copyrighted melody, lyric, sample, or released beat. Do not add performer identity that was not in the source.

Return concise JSON only with these fields: reference, era, primary_engine, traits (array of strings), instrument_bias (array of strings), rhythm, drums, bass, relationship, harmony, texture, density, arrangement, transitions, vocal_space, mix, guardrail, confidence_note, preserve_character, preserved_elements (array), translated_elements (array), vague_terms (array), source_prompt, exclude. Every field except the arrays must be a plain human-readable string or number, never a nested object.
"""


PERFORMANCE_SYSTEM = """You are the Performance Lane Decoder inside MasterMind Suno Studio.
The user may provide a named singer/rapper, a vocal era, a specific performance reference, or a plain-language performance lane. Your job is to translate that reference into TRANSFERABLE PERFORMER MECHANICS for an original performance — not to clone a real person's voice.

Separate PERFORMANCE from PRODUCTION. Do not describe drums, bass, instruments, harmony, mixing, or beat construction unless a tiny amount of context is necessary to explain vocal timing. Focus on how the performer uses the voice: role, phrasing, rhythmic placement, melodic behavior, dynamics, articulation, sustain/release, register strategy, ornamentation, ad-lib/backing-vocal behavior, hook behavior, emotional posture, and conversational vs sung balance.

If the reference is a living or recognizable artist, do not instruct the selected artist to imitate an exact voice, unique timbre, signature melody, copyrighted lyric, recognizable ad-lib, or one-to-one performance. Extract high-level transferable behaviors only. The final performance_overlay MUST NOT contain the reference artist's name. It must also avoid copying sex, ethnicity, age, exact vocal identity, or a unique signature sound.

The supplied artist_lock and artist_vocal_style are controlling constraints. Preserve the selected MasterMind artist's core voice, sex, register identity, chest/head balance, maturity, persona, and singer/rapper role. When a reference conflicts with that lock, translate only compatible behaviors (for example timing, phrase length, hook architecture, dynamic restraint, consonant attack, sustain length, or ornament density) and explain the conflict in compatibility_notes. Do not redesign Marcell Vance into a high tenor or the Female Project into another singer.

ARTIST TYPE SEPARATION: artist_type and artist_type_guardrail are controlling constraints when supplied. Borrow performance mechanics without changing what kind of artist the selected MasterMind artist is. A singer-first grown contemporary melodic R&B rider must not become rapper-first, boyish pop, lounge crooner, quiet-storm singer or retro-soul vocalist merely because a reference leans that way.

AGE / CURRENTNESS SEPARATION: preserve an adult artist's mature age-presence even when borrowing very current rhythmic behavior. Do not youth-code the selected artist to make the performance hip, and do not slow, croon, or retro-code the performance to make the artist mature. A mature artist may use quick pickups, clipped endings, syncopation and melodic-rap fluency while retaining seasoned vocal weight and restraint.

If web search is enabled and the named reference is contemporary, ambiguous, or era-specific, research enough to ground the high-level performance description. Do not reproduce copyrighted lyrics.

Return concise JSON only with these plain-string fields: reference, era, role, tone_behavior, register_behavior, phrasing, rhythmic_behavior, melody_behavior, dynamics, articulation, sustain_release, ornamentation, adlibs_bgv, hook_behavior, emotional_posture, compatibility_notes, performance_overlay, guardrail, confidence_note. performance_overlay must be a compact Suno-facing instruction of roughly 120-220 characters containing only transferable performer behavior, with no reference artist name and no production instructions. Every field must be a plain human-readable string, never a nested object or array.
"""


SONG_DECONSTRUCT_SYSTEM = """You are the Song Deconstructor inside MasterMind Suno Studio.
The user supplies a song/record reference, optional era/version, target artist lock, and extra direction. Deconstruct the reference into THREE SEPARATE transferable lanes for building an ORIGINAL record:
1) PRODUCTION DNA — the mechanics around the performer.
2) PERFORMANCE DNA — how the lead vocal/rap performance behaves.
3) CONCEPT / SONGWRITING DNA — the structural idea, dramatic logic, perspective, hook function, section jobs, scene/evidence strategy and emotional arc.

If web search is enabled and the song/reference is contemporary, ambiguous, obscure, version-specific, or factual grounding would materially improve the deconstruction, research it first.

COPYRIGHT / ORIGINALITY RULE: do not quote or reproduce copyrighted lyrics, melodies, distinctive riffs, exact chord sequences, unique sample sequences, signature ad-libs, or a one-to-one arrangement. Do not instruct the user to imitate a recognizable voice. Translate the source into high-level transferable mechanics.

ARTIST IDENTITY RULE: artist_lock, artist_vocal_style, artist_type and artist_type_guardrail are controlling constraints. Performance DNA may borrow compatible phrasing, timing, dynamics, articulation, sustain, ornament density, hook behavior and emotional posture, but it must not replace the selected artist's core timbre, sex, range identity, persona, or singer/rapper role. Mature/adult identity and contemporary rhythmic agility are independent: never make the artist younger in order to sound current, and never make the delivery slower, loungey or crooner-like in order to sound mature.

PRODUCTION DNA must be a JSON object using exactly these fields: reference, era, primary_engine, traits (array of strings), instrument_bias (array of strings), rhythm, drums, bass, relationship, harmony, texture, density, arrangement, transitions, vocal_space, mix, guardrail, confidence_note. Except traits and instrument_bias, all fields must be plain strings.

PERFORMANCE DNA must be a JSON object using exactly these plain-string fields: reference, era, role, tone_behavior, register_behavior, phrasing, rhythmic_behavior, melody_behavior, dynamics, articulation, sustain_release, ornamentation, adlibs_bgv, hook_behavior, emotional_posture, compatibility_notes, performance_overlay, guardrail, confidence_note. performance_overlay must be roughly 120-220 characters, contain only transferable behavior, contain no artist/song name, and contain no production instructions.

CONCEPT DNA must be a JSON object using exactly these fields: reference, core_premise, point_of_view, audience_relation, central_tension, stakes, hook_function, verse_1_job, verse_2_job, bridge_turn, scene_logic, evidence_style, emotional_arc, social_context, lyric_density, quotable_strategy, production_implications, must_avoid, originality_guardrail, confidence_note. must_avoid must be an array of strings; every other field must be a plain string.

Return concise JSON only with top-level fields: reference, production, performance, concept.
"""

CONCEPT_SYSTEM = """You are the Concept Deconstructor / Translator inside MasterMind Suno Studio.
The user may give either THEIR OWN raw song concept/situation or a REFERENCE concept from an existing song, film, scene, cultural situation, archetype, or premise. Your job is to turn it into an original, usable Concept DNA for songwriting and production planning.

If source_type is MY IDEA, preserve the user's core truth, situation and stakes while making the concept more concrete, scene-ready, structurally useful and non-generic. If source_type is REFERENCE, extract only transferable conceptual logic and create sufficient distance from the source. Do not copy copyrighted lyrics, scene dialogue, distinctive plot beats, titles, melodies, or signature lines.

Translate vague ideas into observable song behavior: who is speaking, to whom, what happened, what is at risk, what contradiction keeps the record alive, what the hook does, what each verse must accomplish, what physical evidence/scenes can carry meaning, what changes by the bridge/final hook, and what production behavior supports the concept.

Respect artist_lock and artist_context. Do not force a concept that contradicts the selected artist's locked identity unless the user explicitly asks to redesign the artist.

Return concise JSON only with these fields: reference, source_type, core_premise, point_of_view, audience_relation, central_tension, stakes, hook_function, verse_1_job, verse_2_job, bridge_turn, scene_logic, evidence_style, emotional_arc, social_context, lyric_density, quotable_strategy, production_implications, must_include, must_avoid, originality_guardrail, confidence_note. must_include and must_avoid must be arrays of plain strings. Every other field must be a plain human-readable string.
"""

PROJECT_SYSTEM = """You are the Project / Album Deconstructor inside MasterMind Suno Studio.
The user may supply either MY PROJECT (their own album/project brief) or a REFERENCE PROJECT (an album, mixtape, EP, artist-era, production era, or project-level lane). Your job is to create TRANSFERABLE PROJECT DNA that helps MasterMind keep many songs coherent without making every song sound the same.

Separate the project layer from the song layer. The project layer may guide sonic continuity, energy pacing, subject distribution, hook strategy, sequencing, production evolution and performance arc, but it must never silently replace the selected artist identity, a specifically applied song production reference, a specifically applied performance lane, or the current song concept. Explicit song-level choices outrank project-level guidance.

For MY PROJECT: preserve the user's stated premise, goals, must-keep elements and intended audience/use. Strengthen structure instead of changing the project's identity.
For REFERENCE: use web research when enabled and useful, then abstract high-level project mechanics only. Do not copy track titles, lyrics, melodies, signature riffs, samples, exact sequencing, artwork, or a recognizable performer voice. Do not instruct a one-to-one recreation.

Build a useful album/project map: premise; sonic spine; how production should evolve across the project; performance arc; concept/subject progression; energy curve; tempo strategy; hook strategy; subject distribution; sequencing logic; reusable track roles; routing keywords that can help match producer/style/blueprint mechanics; and cohesion/originality guardrails.

project_overlay must be a concise, name-free, Suno/Producer-Engine-safe project-level cohesion instruction. It should describe transferable mechanics and continuity, not the source project name. It must not override a song's Primary Engine.

Return concise JSON only with these fields: reference, source_type, era, project_premise, sonic_spine, production_evolution, performance_arc, concept_progression, energy_curve, tempo_strategy, hook_strategy, subject_distribution, sequencing_logic, track_roles (array of short strings), routing_keywords (array of mechanical/functional phrases), project_overlay, cohesion_guardrail, originality_guardrail, confidence_note. Every non-array field must be a plain string.
"""


PERSONA_SYSTEM = """You are the Persona Builder inside MasterMind Suno Studio.
Create a concise reusable vocal-persona prompt from the user's sex/voice category, range, role, artist_type, artist_type_guardrail, tone, performance behavior, cultural_vocal_language, age_presence, currentness, and character notes. Keep persona identity separate from production style.

ARTIST TYPE HARD RULE: Treat artist_type as its own controlling identity dimension: what kind of musical artist the listener perceives. It is separate from age/presence, physical voice, performance lane and production. Preserve artist_type and artist_type_guardrail explicitly. Do not let a current beat turn a grown contemporary R&B rider into a boyish rapper-pop act; do not let maturity turn the artist into a lounge, quiet-storm, retro-soul or stately crooner unless that artist type is explicitly requested.

MATURITY / CURRENTNESS HARD RULE: Treat adult maturity and contemporary rhythmic fluency as independent dimensions. Maturity controls perceived adult age, masculine/feminine weight, restraint, diction, emotional gravity and lived-in confidence. NEVER translate maturity into slower tempo, dragged phrasing, lounge/crooner behavior, stately delivery, retro-soul posture or reduced rhythmic agility. Currentness controls pocket mobility, quick pickups, syncopation, melodic-rap fluency, clipped phrase turns and the ability to ride active modern drums. NEVER translate currentness into a younger voice, boyish/girlish tone, teen-coded energy, bright-pop diction or slang-dependent characterization. The intended target can sound unmistakably grown before the lyric starts and still move naturally on a hip, hard, current beat.

CULTURAL PERFORMANCE RULE: If cultural_vocal_language is supplied, preserve it as an explicit performance constraint. Translate it into concrete high-level vocal mechanics such as rhythmic placement, consonant behavior, pitch inflection, ornament density, sustain behavior, grit, timing and contemporary-vs-retro posture. Do not erase it into generic pop diction, and do not replace it with racial stereotypes or a named-singer imitation. For Marcell Vance, preserve a mature contemporary Black American R&B performance language while keeping his deep lyric baritone identity; avoid bright clean-pop/indie/folk/country/Broadway defaults and avoid retro gospel or classic-soul redesign.

Build a CLEAN A CAPPELLA SINGING identity sample, not a speech sample. HARD REQUIREMENTS:
- 60–90 seconds of usable continuous solo vocal.
- The sample lyric must be roughly 130–180 words. Do not return a tiny 4–6 line passage.
- It must be SUNG THROUGHOUT. No spoken-word passage and no rap-only passage. Conversational phrasing may affect timing, but melody must remain present from beginning to end.
- Start in the comfortable low/core register, travel naturally through the comfortable mid register, include one rhythmically active melodic phrase, one legato phrase, two clean 2–4 second held notes, and one controlled dynamic lift.
- No instrumental, no harmonies/choir, no doubled lead, no filler ad-libs, no beatboxing or mouth percussion, no production effects, and no extreme notes chosen only to show off range.
- The goal is identity capture: core register, chest/head balance, consonants, rhythmic timing, sustain behavior, melodic phrasing, dynamics, cultural performance language, and natural texture.
- Do not write a self-referential vocal exercise as the sample lyric when an artist preset is supplied. Write a short original mini-song that naturally exposes the requested voice and phrasing without copying an existing song, singer, melody or lyric.

Also return an acapella_style_prompt written as a concise Suno-ready generation instruction that reinforces SOLO UNACCOMPANIED SINGING and the 60–90 second target. Keep negative voice behaviors in the separate exclude field, not inside the positive style prompt.
Return concise JSON only with: persona_prompt, sex, voice_category, acapella_type, acapella_length, acapella_instructions (array), acapella_style_prompt, acapella_exclude (array), acapella_sample_lyric.
"""


def parse_jsonish(text: str):
    text = text.strip()
    try:
        return json.loads(text)
    except Exception:
        m = re.search(r"\{.*\}", text, re.S)
        if not m:
            raise RuntimeError("The AI response was not valid JSON.")
        try:
            return json.loads(m.group(0))
        except Exception as e:
            raise RuntimeError("The AI response could not be parsed as JSON.") from e


LEGACY_VAGUE_MAP = {
    "ominous": "low-register minor-key tension with short harmonic movement",
    "menacing": "hard low-register anchors, restrained sustain, and abrupt rhythmic returns",
    "cinematic": "section-developed instrumentation with contrast created by register and density changes",
    "luxurious": "clean separation, restrained harmonic color, polished low end, and controlled stereo width",
    "aggressive": "harder drum transients, denser pickups, shorter bass answers, and quicker section returns",
    "seductive": "low-slung syncopated",
    "dark": "reduced-brightness minor/modal",
    "eerie": "detuned or narrow high-register accents against stable low anchors",
    "emotional": "clear harmonic tension/release and section-specific melodic lift",
    "atmospheric": "controlled sustained texture behind the primary engine without masking the vocal",
    "futuristic": "clean synthetic timbres, short digital counterlines, and precise stereo placement",
    "moody": "minor/modal harmonic restraint and slower harmonic movement",
    "playful": "syncopated call-and-response accents and quick instrumental replies",
}



def mechanicalize_legacy(text: str) -> str:
    out = re.sub(r"\s+", " ", str(text or "")).strip()
    for word, repl in LEGACY_VAGUE_MAP.items():
        out = re.sub(rf"\b{re.escape(word)}\b", repl, out, flags=re.I)
    return re.sub(r"\s{2,}", " ", out).strip(" ;,.|")


def legacy_clauses(text: str):
    raw = re.sub(r"\r\n?", "\n", str(text or ""))
    pieces = re.split(r"\s*\|\s*|\n+|(?<=[.;])\s+", raw)
    return [re.sub(r"\s+", " ", x).strip(" ;|\t") for x in pieces if x.strip(" ;|\t")]


def pick_legacy_clauses(clauses, pattern: str, limit=4):
    rx = re.compile(pattern, re.I)
    found = []
    for c in clauses:
        if rx.search(c):
            mc = mechanicalize_legacy(c)
            if mc and mc not in found:
                found.append(mc)
        if len(found) >= limit:
            break
    return "; ".join(found)


def pick_best_legacy_clauses(clauses, include_pattern: str, exclude_pattern: str = "", limit=2):
    inc = re.compile(include_pattern, re.I)
    exc = re.compile(exclude_pattern, re.I) if exclude_pattern else None
    ranked = []
    for idx, c in enumerate(clauses):
        hits = len(inc.findall(c))
        if not hits:
            continue
        penalty = 3 if exc and exc.search(c) else 0
        if idx == 0 and len(c) < 80 and not re.search(r"\bBPM\b|\btempo\b", c, re.I):
            penalty += 4
        score = hits * 3 - penalty
        if score > 0:
            ranked.append((score, -idx, c))
    ranked.sort(reverse=True)
    chosen = sorted(ranked[:limit], key=lambda x: -x[1])
    out = []
    for _, _, c in chosen:
        mc = mechanicalize_legacy(c)
        if mc and mc not in out:
            out.append(mc)
    return "; ".join(out)


def extract_legacy_exclusions(text: str):
    found = []
    for m in re.finditer(r"\b(?:no|avoid|without)\s+([^|.;]+)", text or "", re.I):
        val = re.sub(r"\s+", " ", m.group(1)).strip(" ,")
        if val and val.lower() not in {x.lower() for x in found}:
            found.append(val)
    for m in re.finditer(r"\bexclude(?:s|d)?\s*:\s*([^|.;]+)", text or "", re.I):
        val = re.sub(r"\s+", " ", m.group(1)).strip(" ,")
        if val and val.lower() not in {x.lower() for x in found}:
            found.append(val)
    return " | ".join(found[:10])


def find_legacy_bpm(text: str) -> str:
    vals = re.findall(r"(?<!\d)(\d{2,3})\s*(?:BPM|bpm)\b", text or "")
    if vals:
        return vals[0] + " BPM"
    m = re.search(r"(?<!\d)(\d{2,3})\s*(?:[-–—]\s*(\d{2,3}))?\s*(?:BPM|bpm)", text or "")
    if m:
        return (m.group(1) + ("-" + m.group(2) if m.group(2) else "") + " BPM")
    return ""


def legacy_primary_engine(text: str) -> str:
    t = (text or "").lower()
    first = t[:180]
    scores = {
        "sample": len(re.findall(r"sample|chop|re[- ]?pitch|vinyl|record fragment|source grain", t)) * 4,
        "bass": len(re.findall(r"\b808\b|\bbass\b|\bsub\b|low[- ]?end", t)) * 2,
        "drums": len(re.findall(r"kick|snare|clap|hat|drum|rim|tom|percussion|cowbell|shaker|woodblock", t)),
        "guitar": len(re.findall(r"guitar|pluck", t)) * 2,
        "keys": len(re.findall(r"piano|rhodes|organ|keyboard|key stab", t)) * 2,
        "synth": len(re.findall(r"synth|arp|arpegg|bell motif|lead motif", t)) * 2,
        "live": len(re.findall(r"live band|live[- ]instrument|live bass|live drums|organic rhythm section", t)) * 4,
    }
    if re.search(r"sample[- ]?first|sample[- ]?based|chopped[- ]?sample", first): scores["sample"] += 8
    if re.search(r"808|bass[- ]?led|bassline|low[- ]?end", first): scores["bass"] += 5
    if re.search(r"drum[- ]?led|drum machine|drum-machine|body[- ]?motion|percussion[- ]?led", first): scores["drums"] += 5
    if re.search(r"guitar[- ]?led|pluck[- ]?led", first): scores["guitar"] += 7
    if re.search(r"piano[- ]?led|keyboard[- ]?led|organ[- ]?led", first): scores["keys"] += 7
    if re.search(r"synth[- ]?led|arp[- ]?led", first): scores["synth"] += 7
    if re.search(r"\bminimal\b[^|.;]{0,60}(guitar|pluck)", t): scores["guitar"] -= 4
    if re.search(r"\bminimal\b[^|.;]{0,60}(piano|rhodes|organ|keyboard)", t): scores["keys"] -= 4
    if re.search(r"\bminimal\b[^|.;]{0,60}synth", t): scores["synth"] -= 3
    if scores["sample"] >= 7:
        return "audible chopped/re-pitched source fragment as the main musical carrier; drums and bass support the sample and do not replace it"
    if scores["live"] >= 7:
        return "live rhythm-section interplay as the primary engine; bass, drums and comping instruments move as one pocket"
    if scores["bass"] >= 7 and scores["drums"] >= 5:
        return "interlocking drum-and-bass pressure system as the primary engine; kick/percussion create forward motion while the bass carries roots, syncopated answers and recognizable turnarounds"
    ranked = sorted(((v, k) for k, v in scores.items()), reverse=True)
    best_score, best = ranked[0]
    if best == "guitar" and best_score >= 4:
        return "guitar/pluck motif as the main musical carrier over an independent drum-and-bass pocket"
    if best == "keys" and best_score >= 4:
        return "keyboard-led motif as the main musical carrier over an independent drum-and-bass pocket"
    if best == "bass" and best_score >= 4:
        return "bass-led movement as the primary engine; drums anchor key impacts while melodic parts leave room for low-end motion"
    if best == "drums" and best_score >= 4:
        return "drum/percussion-led pocket as the primary engine; bass and melody reinforce the rhythmic movement without duplicating it"
    if best == "synth" and best_score >= 4:
        return "synth/melodic motif as the primary carrier over a separate rhythm-section pocket"
    return "interlocking rhythm section plus one clearly audible lead musical motif; preserve the source prompt's strongest repeated carrier"



def extract_instruments(text: str):
    vocab = [
        "electric piano", "rhodes", "piano", "organ", "electric guitar", "acoustic guitar", "muted guitar",
        "guitar harmonics", "guitar", "analog synth", "glassy synth", "synth", "pad", "strings", "brass",
        "horns", "bells", "bell", "whistle", "flute", "choir", "vocal chop", "sample", "clav", "clavinet",
        "harp", "mallet", "marimba"
    ]
    low = (text or "").lower()
    hits = []
    for item in vocab:
        pos = low.find(item)
        if pos < 0:
            continue
        prefix = low[max(0, pos-24):pos]
        if re.search(r"(?:\bno\b|\bavoid\b|\bwithout\b|\bexclude\b)[^|.;]{0,20}$", prefix):
            continue
        if item not in hits:
            hits.append(item)
    if any(x in hits for x in ("electric guitar", "acoustic guitar", "muted guitar", "guitar harmonics")):
        hits = [x for x in hits if x != "guitar"]
    if any(x in hits for x in ("analog synth", "glassy synth")):
        hits = [x for x in hits if x != "synth"]
    if "electric piano" in hits or "rhodes" in hits:
        if "piano" in hits and " piano" not in low.replace("electric piano", ""):
            hits.remove("piano")
    return hits[:10]



def infer_relationship(drums: str, bass: str, source: str) -> str:
    t = " ".join([drums or "", bass or "", source or ""]).lower()
    if re.search(r"independent|answer|off[- ]beat|syncopat|pickup", t):
        return "kick and bass share key anchors, then separate: bass uses syncopated answers and phrase turnarounds instead of mirroring every kick"
    if re.search(r"long root|sustain|held bass|anchored bass|stable root", t):
        return "bass holds the floor with sustained/root notes while kick pickups create forward motion around it"
    if re.search(r"live bass|fretless|bass guitar|live rhythm", t):
        return "bass behaves like an independent musician around the kick, locking selected downbeats and moving through phrase endings"
    return "kick and bass share the low-end center but alternate secondary motion; preserve clear separation and avoid one-for-one mirroring"


def translate_legacy_style_local(source: str, name: str = "", preserve_character=75):
    source = re.sub(r"\s+", " ", str(source or "")).strip()
    if not source:
        raise ValueError("Paste or upload an old STYLE first.")
    try:
        preserve = max(0, min(100, int(float(preserve_character))))
    except Exception:
        preserve = 75
    clauses = legacy_clauses(source)
    bpm = find_legacy_bpm(source)
    rhythm = pick_best_legacy_clauses(clauses, r"\bBPM\b|half[- ]?time|double[- ]?time|\bpocket\b|\bgroove\b|\bbounce\b|\bswing\b|\bgrid\b|body[- ]?motion|forward motion|\btempo\b", r"arrangement|intro|verse|hook|chorus|bridge|outro|vocal|baritone|mezzo|contralto|tenor|\bmix\b", 2)
    if bpm and bpm not in rhythm:
        rhythm = (bpm + ("; " + rhythm if rhythm else ""))
    drums = pick_best_legacy_clauses(clauses, r"kick|snare|clap|hat|drum|rim|tom|percussion|cowbell|shaker|tambourine|woodblock|transient", r"\bmix\b|vocal[- ]?forward|arrangement|intro|verse|hook|chorus|bridge|outro", 2)
    bass = pick_best_legacy_clauses(clauses, r"\b808\b|\bbass\b|\bsub\b|low[- ]?end|\broot|\bslide|turnaround", r"\bmix\b|vocal[- ]?forward|arrangement|intro|verse|hook|chorus|bridge|outro", 2)
    harmony = pick_best_legacy_clauses(clauses, r"chord|harmon|minor|major|modal|voic|piano|rhodes|organ|key stab|keyboard", r"vocal|baritone|mezzo|contralto|tenor|back[- ]?up", 2)
    texture = pick_best_legacy_clauses(clauses, r"texture|grain|vinyl|haze|pad|saturat|filter|distort|reverb|delay|\bdry\b|\bwet\b|glassy|analog|airy|\bdark\b|ominous|cinematic|luxur|seduct|atmospher", r"vocal|baritone|mezzo|contralto|tenor|\bBPM\b|half[- ]?time|\bpocket\b|kick|snare|clap|hat|drum|tom|woodblock|percussion", 2)
    density = pick_best_legacy_clauses(clauses, r"\bsparse\b|\bdense\b|open (?:space|lane)|negative space|\bspace\b|\bspaces\b|\bminimal\b|\bbusy\b|unclutter|\blayer|constant|continuous", r"vocal|baritone|mezzo|contralto|tenor", 2)
    arrangement = pick_best_legacy_clauses(clauses, r"intro|verse|hook|chorus|bridge|outro|section|arrangement|build|breakdown|post[- ]?hook|8[- ]?bar|eight[- ]?bar|final", "", 3)
    transitions = pick_best_legacy_clauses(clauses, r"transition|drop|\bmute\b|stop|pickup|fill|turnaround|reverse|switch|pullback|suspension|return", "", 3)
    legacy_vocal = pick_legacy_clauses(clauses, r"vocal|singer|rapper|lead voice|lead vocal|bgv|back[- ]?up|harmonies|melisma|baritone|mezzo|contralto|tenor", 4)
    if legacy_vocal:
        bgv = "very minimal backing vocals/harmonies" if re.search(r"very minimal|minimal back[- ]?up|minimal backing|minimal harmon", legacy_vocal, re.I) else "backing-vocal behavior only where compatible with the selected artist"
        vocal_space = f"protect the selected artist's lead-vocal identity and clear center lane; {bgv}; do not transfer legacy singer range, gender, timbre or persona from the old STYLE"
    else:
        vocal_space = "protect a clear center lane for the selected artist; musical replies should answer phrases rather than continuously occupy the same register"
    mix = pick_best_legacy_clauses(clauses, r"\bmix\b|mono|stereo|\bwide\b|center|vocal[- ]?forward|clean low[- ]?end|master|close[- ]?mic|depth|physical drums", r"baritone|mezzo|contralto|tenor", 2)
    instruments = extract_instruments(source)
    vague = sorted({w for w in LEGACY_VAGUE_MAP if re.search(rf"\b{re.escape(w)}\b", source, re.I)})
    exclusions = extract_legacy_exclusions(source)
    primary = legacy_primary_engine(source)

    # Preserve source clauses where extraction is thin instead of inventing a generic style.
    fallback = mechanicalize_legacy("; ".join(clauses[:3]))
    rhythm = rhythm or (bpm if bpm else "preserve the original pulse and syncopation; do not quantize away the source prompt's rhythmic feel")
    drums = drums or "preserve the original drum weight and placement; define kick/snare impacts clearly and avoid replacing them with a generic kit"
    bass = bass or "preserve the original low-end role; keep bass rhythm distinct from kick placement and retain the source prompt's sustain/answer behavior"
    harmony = harmony or "preserve the source prompt's chord color and harmonic pace; use concise voicings that leave the lead-vocal range open"
    texture = texture or (mechanicalize_legacy(fallback) if fallback else "retain the source prompt's surface character without substituting a generic pad wash")
    density = density or "preserve the source prompt's apparent density; leave deliberate lanes between the primary engine, rhythm section and lead vocal"
    arrangement = arrangement or "preserve the source prompt's section logic; make verse/hook changes audible through addition, subtraction or motif variation rather than unrelated beat switches"
    transitions = transitions or "use short source-consistent transitions such as fills, mutes, pickups, motif edits or brief pullbacks; avoid generic risers"
    mix = mix or "preserve the source prompt's low-end weight and surface character with clear kick/bass separation, controlled width and a vocal-forward center"
    relationship = infer_relationship(drums, bass, source)

    if preserve >= 85:
        guard = "Preserve the legacy prompt's BPM, pocket, primary instrument family, rhythm-section behavior, section logic and mix character unless the source contradicts itself; translate wording, not identity."
    elif preserve >= 60:
        guard = "Preserve the legacy prompt's recognizable primary engine, pocket, instrument family and section behavior while clarifying vague wording into playable mechanics; do not genericize the result."
    else:
        guard = "Repair vague or weak construction while retaining the legacy prompt's most distinctive engine, rhythm and instrument identity; modernization must not collapse into a generic house style."

    preserved = []
    for label, val in [("BPM/pocket", rhythm), ("drum behavior", drums), ("bass role", bass), ("instrument family", ", ".join(instruments)), ("section logic", arrangement), ("mix character", mix)]:
        if val:
            preserved.append(f"{label}: {val}")
    translated = [f"{w} -> {LEGACY_VAGUE_MAP[w]}" for w in vague]
    ref = (name or "Legacy Style Translation").strip()
    fingerprint = f"ENGINE {primary}; POCKET {rhythm}; DRUMS {drums}; BASS {bass}; MUSIC {', '.join(instruments) if instruments else harmony}; SECTIONS {arrangement}"
    return {
        "reference": ref,
        "era": "legacy style translation",
        "reference_type": "legacy_style_translation",
        "source_bank": "Legacy Style Translator",
        "primary_engine": primary,
        "traits": [mechanicalize_legacy(c) for c in clauses[:4]],
        "instrument_bias": instruments,
        "rhythm": rhythm,
        "drums": drums,
        "bass": bass,
        "relationship": relationship,
        "harmony": harmony,
        "texture": texture,
        "density": density,
        "arrangement": arrangement,
        "transitions": transitions,
        "vocal_space": vocal_space,
        "mix": mix,
        "guardrail": guard,
        "confidence_note": "Local deterministic translation from the supplied legacy prompt; use AI refinement only if the old wording is ambiguous or underspecified.",
        "preserve_character": preserve,
        "preserved_elements": preserved[:6],
        "translated_elements": translated,
        "vague_terms": vague,
        "source_prompt": source,
        "exclude": exclusions,
        "mechanics_complete": True,
        "integrity_version": "1.5-legacy",
        "mechanical_fingerprint": fingerprint,
    }


def extract_legacy_file_text(filename: str, data_b64: str) -> str:
    if not data_b64:
        raise ValueError("Uploaded file contained no data.")
    if "," in data_b64 and data_b64.lstrip().lower().startswith("data:"):
        data_b64 = data_b64.split(",", 1)[1]
    try:
        raw = base64.b64decode(data_b64, validate=False)
    except Exception as e:
        raise ValueError("Could not decode the uploaded file.") from e
    if len(raw) > 8_000_000:
        raise ValueError("Legacy style file is too large. Use a text/Word file under 8 MB.")
    ext = Path(filename or "").suffix.lower()
    if ext == ".docx":
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as z:
                xml = z.read("word/document.xml")
            root = ET.fromstring(xml)
            ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
            paras = []
            for p in root.findall(".//w:p", ns):
                parts = [t.text or "" for t in p.findall(".//w:t", ns)]
                line = "".join(parts).strip()
                if line:
                    paras.append(line)
            text = "\n".join(paras)
        except Exception as e:
            raise ValueError("Could not read this DOCX file. Paste the style text instead.") from e
    elif ext in {".txt", ".md", ".json", ".csv", ""}:
        for enc in ("utf-8-sig", "utf-8", "cp1252"):
            try:
                text = raw.decode(enc)
                break
            except Exception:
                text = ""
        if not text:
            raise ValueError("Could not decode the uploaded text file.")
    else:
        raise ValueError("Supported legacy files: .txt, .md, .json, .csv, .docx. You can also paste the STYLE directly.")
    text = text.strip()
    if not text:
        raise ValueError("No readable style text was found in the uploaded file.")
    return text


def legacy_to_style_bank_entry(style: dict, name: str = ""):
    ref = str(name or style.get("reference") or "Translated Legacy Style").strip()
    entry_id = "legacy_style_" + safe_slug(ref).lower()
    bpm_match = re.search(r"(?<!\d)(\d{2,3})\s*BPM\b", str(style.get("rhythm") or ""), re.I)
    bpm = bpm_match.group(1) if bpm_match else ""
    primary = str(style.get("primary_engine") or "").strip()
    rhythm = str(style.get("rhythm") or "").strip()
    drums = str(style.get("drums") or "").strip()
    bass = str(style.get("bass") or "").strip()
    instruments = style.get("instrument_bias") or []
    if not isinstance(instruments, list):
        instruments = [str(instruments)] if instruments else []
    arrangement = str(style.get("arrangement") or "").strip()
    fp = str(style.get("mechanical_fingerprint") or f"ENGINE {primary}; POCKET {rhythm}; DRUMS {drums}; BASS {bass}; MUSIC {', '.join(instruments)}; SECTIONS {arrangement}")
    return {
        "id": entry_id,
        "name": ref,
        "bank": "My Translated Styles",
        "category": "Legacy Translation",
        "era": str(style.get("era") or "legacy").strip(),
        "bpm": bpm,
        "production": str(style.get("source_prompt") or "").strip(),
        "exclude": str(style.get("exclude") or "").strip(),
        "sources": ["Legacy Style Translator"],
        "source_prompt": str(style.get("source_prompt") or "").strip(),
        "primary_engine": primary,
        "movement_owner": "primary engine + rhythm section",
        "rhythm": rhythm,
        "drums": drums,
        "bass": bass,
        "relationship": str(style.get("relationship") or "").strip(),
        "harmony": str(style.get("harmony") or "").strip(),
        "instrument_bias": instruments,
        "texture": str(style.get("texture") or "").strip(),
        "density": str(style.get("density") or "").strip(),
        "arrangement": arrangement,
        "transitions": str(style.get("transitions") or "").strip(),
        "vocal_space": str(style.get("vocal_space") or "").strip(),
        "mix": str(style.get("mix") or "").strip(),
        "guardrail": str(style.get("guardrail") or "").strip(),
        "mechanics_complete": True,
        "integrity_version": "1.5-legacy",
        "mechanical_fingerprint": fp,
        "custom": True,
        "preserve_character": style.get("preserve_character", 75),
        "saved_at": datetime.now().isoformat(timespec="seconds"),
    }


class Handler(SimpleHTTPRequestHandler):
    server_version = "MasterMindLocal/1.8"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC), **kwargs)

    def log_message(self, fmt, *args):
        sys.stdout.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))

    def end_headers(self):
        # UI is a local development workspace. Never let a stale browser copy hide a newly applied update.
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def send_json(self, payload, status=200):
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def read_json(self):
        length = int(self.headers.get("Content-Length") or "0")
        if length > 10_000_000:
            raise ValueError("Request too large")
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8"))

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/atomic/browser_result":
            if not os.environ.get("MASTERMIND_VERIFY_TOKEN") or self.headers.get("X-MasterMind-Control") != os.environ.get("MASTERMIND_VERIFY_TOKEN"):
                return self.send_json({"error": "Verification token required"}, 403)
            return self.send_json(ATOMIC_BROWSER_REPORT)
        if parsed.path == "/api/bootstrap":
            return self.send_json(bootstrap_payload())
        if parsed.path == "/api/knowledge/export":
            return self.send_json({"format": "mastermind.knowledge.export.v1", "engine_version": APP_VERSION,
                "exported_at": datetime.now().isoformat(timespec="seconds"),
                "knowledge": effective_knowledge(), "patch_history": load_json(KNOWLEDGE_HISTORY_PATH, [])})
        if parsed.path == "/api/knowledge/schema":
            return self.send_json({"filename": "MasterMind_Knowledge_Patch_Schema.md",
                "content": KNOWLEDGE_SCHEMA_PATH.read_text(encoding="utf-8")})
        if parsed.path == "/api/presets/export":
            return self.send_json(export_presets())
        if parsed.path == "/api/load_project":
            name = (parse_qs(parsed.query).get("name") or [""])[0]
            path = PROJECTS / f"{safe_slug(name)}.json"
            if not path.exists():
                return self.send_json({"error": "Project not found"}, 404)
            return self.send_json(load_json(path, {}))
        if parsed.path == "/api/health":
            release_checks = validate_release(ROOT)
            release_ok, _release_warn = release_checks_ok(release_checks)
            contract = load_release_contract(ROOT)
            return self.send_json({"ok": release_ok, "atomic_mode": bool(os.environ.get("MASTERMIND_ATOMIC_CHILD")), "runtime_pid": os.getpid(), "runtime_root": str(ROOT), "runtime_token": os.environ.get("MASTERMIND_VERIFY_TOKEN", ""), "version": APP_VERSION, "release_contract_version": str(contract.get("version") or ""), "release_contract_ok": release_ok, "ai_configured": bool(os.environ.get("OPENAI_API_KEY")), "model": load_json(SETTINGS_PATH, {}).get("ai_model", "gpt-5.6-terra")})
        if parsed.path == "/api/system/selftest":
            return self.send_json(system_selftest())
        if parsed.path == "/api/update/status":
            return self.send_json(update_status())
        return super().do_GET()

    def do_POST(self):
        with MUTATION_LOCK:
            return self._post_serialized()

    def _post_serialized(self):
        global ATOMIC_BROWSER_REPORT
        parsed = urlparse(self.path)
        try:
            body = self.read_json()
            if (os.environ.get("MASTERMIND_VALIDATION") == "1" or (UPDATES / "transaction.json").exists() or (UPDATES / "atomic_transaction.json").exists()) and parsed.path not in {"/api/system/selftest", "/api/system/shutdown", "/api/atomic/browser_result"}:
                return self.send_json({"error": "Update verification is in progress; changes are temporarily paused."}, 503)
            if parsed.path == "/api/atomic/browser_result":
                if not os.environ.get("MASTERMIND_VERIFY_TOKEN") or self.headers.get("X-MasterMind-Control") != os.environ.get("MASTERMIND_VERIFY_TOKEN"):
                    return self.send_json({"error": "Verification token required"}, 403)
                report = body.get("report") or {}
                result = system_selftest(report)
                checks = dict(body.get("checks") or {})
                checks["ui_registry"] = result.get("ok") is True
                ATOMIC_BROWSER_REPORT = {"complete": True, "checks": checks, "errors": body.get("errors", [])}
                return self.send_json({"ok": True})
            if parsed.path == "/api/knowledge/patch":
                patch = body.get("patch") if isinstance(body, dict) and "patch" in body else body
                result = apply_and_save(KNOWLEDGE_PACK_PATH, CUSTOM_KNOWLEDGE_PATH, KNOWLEDGE_HISTORY_PATH, patch)
                return self.send_json(result)
            if parsed.path == "/api/presets/import":
                bundle = body.get("presets") if isinstance(body, dict) and "presets" in body else body
                return self.send_json(import_presets(bundle))
            if parsed.path == "/api/save_project":
                name = str(body.get("name") or "Untitled Project").strip()
                payload = body.get("payload") or {}
                record = {
                    "name": name,
                    "updated_at": datetime.now().isoformat(timespec="seconds"),
                    "payload": payload,
                }
                save_json(PROJECTS / f"{safe_slug(name)}.json", record)
                return self.send_json({"ok": True, "name": name, "updated_at": record["updated_at"]})

            if parsed.path == "/api/save_custom_style":
                style = body.get("style") or {}
                if not style.get("reference"):
                    return self.send_json({"error": "Style reference is required"}, 400)
                require_production_dna(style, "Custom Style DNA")
                customs = load_json(CUSTOM_STYLES_PATH, [])
                style.setdefault("id", "custom_" + safe_slug(style["reference"]).lower())
                style["custom"] = True
                style["saved_at"] = datetime.now().isoformat(timespec="seconds")
                customs = [x for x in customs if x.get("id") != style.get("id")]
                customs.append(style)
                save_json(CUSTOM_STYLES_PATH, customs)
                return self.send_json({"ok": True, "style": style})

            if parsed.path == "/api/legacy/extract":
                filename = str(body.get("filename") or "legacy_style.txt")
                text = extract_legacy_file_text(filename, str(body.get("data_base64") or ""))
                return self.send_json({"ok": True, "filename": filename, "text": text})

            if parsed.path == "/api/legacy/translate_local":
                style = translate_legacy_style_local(
                    str(body.get("source_prompt") or ""),
                    str(body.get("name") or ""),
                    body.get("preserve_character", 75),
                )
                return self.send_json({"ok": True, "style": style})

            if parsed.path == "/api/save_custom_style_bank":
                style = body.get("style") or {}
                if not isinstance(style, dict) or not style.get("primary_engine"):
                    return self.send_json({"error": "Translate a complete legacy style first."}, 400)
                require_production_dna(style, "Legacy Style DNA")
                entry = legacy_to_style_bank_entry(style, str(body.get("name") or ""))
                customs = load_json(CUSTOM_STYLE_BANK_PATH, [])
                customs = [x for x in customs if x.get("id") != entry.get("id")]
                customs.append(entry)
                save_json(CUSTOM_STYLE_BANK_PATH, customs)
                return self.send_json({"ok": True, "style": entry})

            if parsed.path == "/api/save_performance_lane":
                perf = body.get("performance") if isinstance(body, dict) else None
                if not isinstance(perf, dict) or not str(perf.get("reference") or "").strip():
                    return self.send_json({"error": "Decode a performance lane before saving it."}, 400)
                require_performance_dna(perf, "Performance Lane DNA")
                entry = dict(perf)
                ref = str(entry.get("reference") or "Performance Lane").strip()
                entry.setdefault("id", "performance_" + safe_slug(ref).lower())
                entry.setdefault("reference_type", "performance_lane")
                entry.setdefault("source_bank", "My Performance Lanes")
                entry.setdefault("integrity_version", "1.6-performance")
                lanes = load_json(CUSTOM_PERFORMANCE_LANES_PATH, [])
                if not isinstance(lanes, list):
                    lanes = []
                rid = str(entry.get("id") or "")
                replaced = False
                for i, old in enumerate(lanes):
                    if isinstance(old, dict) and (str(old.get("id") or "") == rid or str(old.get("reference") or "").strip().lower() == ref.lower()):
                        lanes[i] = entry
                        replaced = True
                        break
                if not replaced:
                    lanes.append(entry)
                save_json(CUSTOM_PERFORMANCE_LANES_PATH, lanes)
                return self.send_json({"ok": True, "performance": entry, "performance_lanes": lanes})

            if parsed.path == "/api/save_song_deconstruction":
                item = body.get("deconstruction") if isinstance(body, dict) else None
                if not isinstance(item, dict) or not str(item.get("reference") or "").strip():
                    return self.send_json({"error": "Deconstruct a song before saving it."}, 400)
                require_production_dna(item.get("production") or {}, "Song Production DNA")
                require_performance_dna(item.get("performance") or {}, "Song Performance DNA")
                require_concept_dna(item.get("concept") or {}, "Song Concept DNA")
                entry = dict(item)
                ref = str(entry.get("reference") or "Song Deconstruction").strip()
                entry.setdefault("id", "song_" + safe_slug(ref).lower())
                entry.setdefault("source_bank", "My Song Deconstructions")
                entry.setdefault("integrity_version", "1.7-song")
                items = load_json(CUSTOM_SONG_DECONSTRUCTIONS_PATH, [])
                if not isinstance(items, list): items = []
                rid = str(entry.get("id") or "")
                items = [x for x in items if not (isinstance(x, dict) and (str(x.get("id") or "") == rid or str(x.get("reference") or "").strip().lower() == ref.lower()))]
                items.append(entry)
                save_json(CUSTOM_SONG_DECONSTRUCTIONS_PATH, items)
                return self.send_json({"ok": True, "deconstruction": entry, "song_deconstructions": items})

            if parsed.path == "/api/save_concept":
                item = body.get("concept") if isinstance(body, dict) else None
                if not isinstance(item, dict) or not str(item.get("reference") or "").strip():
                    return self.send_json({"error": "Translate a concept before saving it."}, 400)
                require_concept_dna(item, "Concept DNA")
                entry = dict(item)
                ref = str(entry.get("reference") or "Concept").strip()
                entry.setdefault("id", "concept_" + safe_slug(ref).lower())
                entry.setdefault("source_bank", "My Concepts")
                entry.setdefault("integrity_version", "1.7-concept")
                items = load_json(CUSTOM_CONCEPTS_PATH, [])
                if not isinstance(items, list): items = []
                rid = str(entry.get("id") or "")
                items = [x for x in items if not (isinstance(x, dict) and (str(x.get("id") or "") == rid or str(x.get("reference") or "").strip().lower() == ref.lower()))]
                items.append(entry)
                save_json(CUSTOM_CONCEPTS_PATH, items)
                return self.send_json({"ok": True, "concept": entry, "concepts": items})

            if parsed.path == "/api/save_project_dna":
                item = body.get("project") if isinstance(body, dict) else None
                if not isinstance(item, dict) or not str(item.get("reference") or "").strip():
                    return self.send_json({"error": "Deconstruct or translate a project before saving it."}, 400)
                require_project_dna(item, "Project DNA")
                entry = dict(item)
                ref = str(entry.get("reference") or "Project DNA").strip()
                entry.setdefault("id", "project_" + safe_slug(ref).lower())
                entry.setdefault("source_bank", "My Project DNA")
                entry.setdefault("integrity_version", "1.9-project")
                items = load_json(CUSTOM_PROJECT_DNA_PATH, [])
                if not isinstance(items, list): items = []
                rid = str(entry.get("id") or "")
                items = [x for x in items if not (isinstance(x, dict) and (str(x.get("id") or "") == rid or str(x.get("reference") or "").strip().lower() == ref.lower()))]
                items.append(entry)
                save_json(CUSTOM_PROJECT_DNA_PATH, items)
                return self.send_json({"ok": True, "project": entry, "project_dna": items})

            if parsed.path == "/api/settings":
                settings = load_json(SETTINGS_PATH, {})
                allowed = {"ai_model", "web_research_for_unknown_styles", "max_style_chars", "open_browser_on_start", "update_manifest_url", "auto_apply_trusted_updates"}
                for k, v in (body or {}).items():
                    if k in allowed:
                        settings[k] = v
                save_json(SETTINGS_PATH, settings)
                return self.send_json({"ok": True, "settings": settings})

            if parsed.path == "/api/system/selftest":
                return self.send_json(system_selftest((body or {}).get("ui_report")))

            if parsed.path == "/api/update/check":
                return self.send_json(check_remote_update(download=bool(body.get("download", True))))

            if parsed.path == "/api/update/apply":
                filename = str(body.get("filename") or "").strip()
                if not filename:
                    pend = pending_updates()
                    if not pend:
                        return self.send_json({"error": "No pending update package is available."}, 400)
                    filename = pend[0]["filename"]
                target = (UPDATE_INBOX / Path(filename).name).resolve()
                if target.parent != UPDATE_INBOX.resolve() or not target.exists():
                    return self.send_json({"error": "Pending update package was not found."}, 404)
                if os.environ.get("MASTERMIND_ATOMIC_CHILD"):
                    with zipfile.ZipFile(target) as package:
                        if "release_contract.json" not in package.namelist() or json.loads(package.read("release_contract.json")).get("atomic_format") != "mastermind.atomic.v1":
                            return self.send_json({"error": "This installation requires a current atomic release ZIP; legacy file-copy packages are not supported."}, 400)
                state = launch_atomic_update(target, self.server.server_port)
                self.send_json({"ok": True, "message": "Update watchdog launched. MasterMind will restart automatically.", "package": target.name, "log": state["log"]})
                return

            if parsed.path == "/api/system/shutdown":
                if os.environ.get("MASTERMIND_ATOMIC_CHILD") and self.headers.get("X-MasterMind-Control") != os.environ.get("MASTERMIND_VERIFY_TOKEN"):
                    return self.send_json({"error": "Watchdog token required"}, 403)
                self.send_json({"ok": True, "message": "MasterMind server is shutting down."})
                threading.Timer(0.3, self.server.shutdown).start()
                return

            if parsed.path == "/api/ai/test":
                text = openai_response("Reply with exactly: MASTER MIND AI READY", "Connection test. No web search.")
                return self.send_json({"ok": True, "text": text, "model": load_json(SETTINGS_PATH, {}).get("ai_model", "gpt-5.6-terra")})

            if parsed.path == "/api/ai/generate_lyrics":
                prompt = json.dumps(body, ensure_ascii=False, indent=2)
                text = openai_response(LYRIC_SYSTEM, prompt)
                return self.send_json({"ok": True, "text": text})

            if parsed.path == "/api/ai/analyze_lyrics":
                prompt = json.dumps(body, ensure_ascii=False, indent=2)
                text = openai_response(ANALYZE_SYSTEM, prompt)
                return self.send_json({"ok": True, "analysis": parse_jsonish(text)})

            if parsed.path == "/api/ai/decode_style":
                use_web = bool(body.get("use_web", True))
                prompt = json.dumps(body, ensure_ascii=False, indent=2)
                text = openai_response(STYLE_SYSTEM, prompt, use_web=use_web)
                style = parse_jsonish(text)
                if not isinstance(style, dict):
                    raise RuntimeError("AI style decoder returned no usable Style DNA.")
                style.setdefault("reference", str(body.get("reference") or "Style Reference"))
                require_production_dna(style, "AI Style DNA")
                style.setdefault("mechanics_complete", True)
                style.setdefault("integrity_version", "1.8-ai")
                return self.send_json({"ok": True, "style": style})

            if parsed.path == "/api/ai/translate_legacy_style":
                prompt = json.dumps(body, ensure_ascii=False, indent=2)
                text = openai_response(LEGACY_STYLE_SYSTEM, prompt)
                style = parse_jsonish(text)
                if not isinstance(style, dict):
                    raise RuntimeError("AI legacy translator returned no usable Style DNA.")
                style.setdefault("reference", str(body.get("name") or "Legacy Style Translation"))
                style.setdefault("era", "legacy style translation")
                style.setdefault("reference_type", "legacy_style_translation")
                style.setdefault("source_bank", "Legacy Style Translator")
                style.setdefault("source_prompt", str(body.get("source_prompt") or ""))
                style.setdefault("preserve_character", body.get("preserve_character", 75))
                style.setdefault("mechanics_complete", True)
                style.setdefault("integrity_version", "1.8-legacy")
                require_production_dna(style, "AI Legacy Style DNA")
                return self.send_json({"ok": True, "style": style})

            if parsed.path == "/api/ai/decode_performance":
                use_web = bool(body.get("use_web", True))
                prompt = json.dumps(body, ensure_ascii=False, indent=2)
                text = openai_response(PERFORMANCE_SYSTEM, prompt, use_web=use_web)
                perf = parse_jsonish(text)
                if not isinstance(perf, dict):
                    raise RuntimeError("AI performance decoder returned no usable Performance DNA.")
                perf.setdefault("reference", str(body.get("reference") or "Performance Lane"))
                perf.setdefault("era", str(body.get("era") or "general / mixed-era"))
                perf.setdefault("reference_type", "performance_lane")
                perf.setdefault("source_bank", "AI Performance Decoder")
                perf.setdefault("integrity_version", "1.8-performance")
                require_performance_dna(perf, "AI Performance DNA")
                return self.send_json({"ok": True, "performance": perf})

            if parsed.path == "/api/ai/deconstruct_song":
                use_web = bool(body.get("use_web", True))
                prompt = json.dumps(body, ensure_ascii=False, indent=2)
                text = openai_response(SONG_DECONSTRUCT_SYSTEM, prompt, use_web=use_web)
                item = parse_jsonish(text)
                if not isinstance(item, dict) or not isinstance(item.get("production"), dict) or not isinstance(item.get("performance"), dict) or not isinstance(item.get("concept"), dict):
                    raise RuntimeError("AI song deconstructor returned incomplete Song DNA.")
                require_production_dna(item["production"], "Song Production DNA")
                require_performance_dna(item["performance"], "Song Performance DNA")
                require_concept_dna(item["concept"], "Song Concept DNA")
                ref = str(body.get("reference") or item.get("reference") or "Song Deconstruction")
                item.setdefault("reference", ref)
                item.setdefault("source_bank", "AI Song Deconstructor")
                item.setdefault("integrity_version", "1.8-song")
                item["production"].setdefault("reference", ref + " — production mechanics")
                item["production"].setdefault("reference_type", "song_deconstruction_production")
                item["production"].setdefault("source_bank", "Song Deconstructor")
                item["performance"].setdefault("reference", ref + " — performance mechanics")
                item["performance"].setdefault("reference_type", "song_deconstruction_performance")
                item["performance"].setdefault("source_bank", "Song Deconstructor")
                item["concept"].setdefault("reference", ref + " — concept mechanics")
                item["concept"].setdefault("source_bank", "Song Deconstructor")
                return self.send_json({"ok": True, "deconstruction": item})

            if parsed.path == "/api/ai/deconstruct_concept":
                use_web = bool(body.get("use_web", False))
                prompt = json.dumps(body, ensure_ascii=False, indent=2)
                text = openai_response(CONCEPT_SYSTEM, prompt, use_web=use_web)
                item = parse_jsonish(text)
                if not isinstance(item, dict):
                    raise RuntimeError("AI concept translator returned no usable Concept DNA.")
                item.setdefault("reference", str(body.get("reference") or "Concept Translation"))
                item.setdefault("source_type", str(body.get("source_type") or "MY IDEA"))
                item.setdefault("source_bank", "AI Concept Translator")
                item.setdefault("integrity_version", "1.8-concept")
                require_concept_dna(item, "AI Concept DNA")
                return self.send_json({"ok": True, "concept": item})

            if parsed.path == "/api/ai/deconstruct_project":
                use_web = bool(body.get("use_web", False))
                prompt = json.dumps(body, ensure_ascii=False, indent=2)
                text = openai_response(PROJECT_SYSTEM, prompt, use_web=use_web)
                item = parse_jsonish(text)
                if not isinstance(item, dict):
                    raise RuntimeError("AI project deconstructor returned no usable Project DNA.")
                item.setdefault("reference", str(body.get("reference") or "Project DNA"))
                item.setdefault("source_type", str(body.get("source_type") or "MY PROJECT"))
                item.setdefault("source_bank", "AI Project Deconstructor")
                item.setdefault("integrity_version", "1.9-project")
                require_project_dna(item, "AI Project DNA")
                return self.send_json({"ok": True, "project": item})

            if parsed.path == "/api/ai/build_persona":
                prompt = json.dumps(body, ensure_ascii=False, indent=2)
                text = openai_response(PERSONA_SYSTEM, prompt)
                return self.send_json({"ok": True, "persona": parse_jsonish(text)})

            return self.send_json({"error": "Unknown API route"}, 404)
        except Exception as e:
            return self.send_json({"error": str(e)}, 400 if isinstance(e, (ValueError, KnowledgeError)) else 500)


def choose_port(preferred: int) -> int:
    for port in range(preferred, preferred + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise RuntimeError("Could not find a free local port.")


def maybe_startup_auto_update() -> bool:
    settings = load_json(SETTINGS_PATH, {})
    if not settings.get("auto_apply_trusted_updates") or not str(settings.get("update_manifest_url") or "").strip():
        return False
    try:
        result = check_remote_update(download=True)
        if not result.get("newer") or not result.get("downloaded"):
            return False
        target = UPDATE_INBOX / result["downloaded"]
        launch_atomic_update(target)
        print(f"Trusted update v{result.get('remote_version')} downloaded; handing off to the watchdog.")
        return True
    except Exception as exc:
        print(f"Auto-update check skipped after error: {exc}")
        return False


def begin_atomic_takeover(port):
    # v1.9.8 is still verifying this initial bootstrap process. Wait until its
    # durable success state is published before handing off to the watchdog.
    def worker():
        for _ in range(180):
            state = load_json(UPDATE_STATE_PATH, {})
            if not (UPDATES / "transaction.json").exists() and state.get("status") == "SUCCESS" and str(state.get("version")) == APP_VERSION:
                from atomic_core import AtomicManager, write_atomic
                manager = AtomicManager(INSTALL_ROOT)
                write_atomic(manager.runtime, {"pid": os.getpid(), "token": os.environ.get("MASTERMIND_VERIFY_TOKEN", ""), "port": port, "root": str(ROOT), "version": APP_VERSION})
                env = {k: v for k, v in os.environ.items() if not k.startswith("MASTERMIND_")}
                subprocess.Popen([sys.executable, str(INSTALL_ROOT / "atomic_watchdog.py"), "--root", str(INSTALL_ROOT), "--mode", "takeover", "--port", str(port)], cwd=INSTALL_ROOT, env=env)
                return
            time.sleep(1)
    threading.Thread(target=worker, daemon=True).start()


def main():
    start_trusted_update_channel_bootstrap()
    if not os.environ.get("MASTERMIND_ATOMIC_CHILD") and os.environ.get("MASTERMIND_VALIDATION") != "1" and not (UPDATES / "transaction.json").exists():
        os.execv(sys.executable, [sys.executable, str(INSTALL_ROOT / "atomic_watchdog.py"), "--root", str(INSTALL_ROOT)])
    if os.environ.get("MASTERMIND_ATOMIC_CHILD") and os.environ.get("MASTERMIND_VALIDATION") != "1":
        registered = False
        for _ in range(50):
            record = load_json(UPDATES / "atomic_runtime.json", {})
            if record.get("pid") == os.getpid() and record.get("token") == os.environ.get("MASTERMIND_VERIFY_TOKEN"):
                registered = True
                break
            time.sleep(0.1)
        if not registered:
            raise SystemExit("Watchdog did not register this runtime; startup stopped.")
        from atomic_core import AtomicManager
        try:
            with AtomicManager(INSTALL_ROOT).lock():
                pass
        except RuntimeError:
            pass  # The watchdog still owns the startup/update transaction.
        else:
            raise SystemExit("Watchdog is no longer supervising startup; server not started.")
    settings = load_json(SETTINGS_PATH, {})
    # Recovery failure is fatal. A supervised verification child is identified
    # by a journal token and a held OS lock, not merely by a matching version.
    if os.environ.get("MASTERMIND_VALIDATION") != "1" and not os.environ.get("MASTERMIND_ATOMIC_CHILD"):
        try:
            import importlib.util as _ilu
            _spec = _ilu.spec_from_file_location("mastermind_update_recovery", UPDATE_MANAGER_PATH)
            _um = _ilu.module_from_spec(_spec); _spec.loader.exec_module(_um)
            if not _um.supervised_restart_allowed():
                recovered = _um.recover_incomplete_transaction()
                if recovered:
                    os.execv(sys.executable, [sys.executable, str(ROOT / "app.py")])
        except Exception as exc:
            print(f"MasterMind startup blocked: update recovery failed: {exc}")
            raise SystemExit(1)
    if not os.environ.get("MASTERMIND_VERIFY_TOKEN") and maybe_startup_auto_update():
        return
    port = int(os.environ["MASTERMIND_VERIFY_PORT"]) if os.environ.get("MASTERMIND_VERIFY_PORT") else choose_port(int(settings.get("port", 8765)))
    url = f"http://127.0.0.1:{port}/"
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print("=" * 68)
    print(f" MasterMind Suno Studio Local v{APP_VERSION}")
    print(f" Local address: {url}")
    print(" Core production helper: OFFLINE-CAPABLE")
    print(" AI features:", "READY" if os.environ.get("OPENAI_API_KEY") else "NOT CONFIGURED (core app still works)")
    print(" Close this window or press Ctrl+C to stop the local server.")
    print("=" * 68)
    if settings.get("open_browser_on_start", True) and not os.environ.get("MASTERMIND_NO_BROWSER"):
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    if not os.environ.get("MASTERMIND_ATOMIC_CHILD") and os.environ.get("MASTERMIND_VALIDATION") != "1":
        begin_atomic_takeover(port)
    elif os.environ.get("MASTERMIND_ATOMIC_CHILD") and os.environ.get("MASTERMIND_VALIDATION") != "1" and settings.get("auto_apply_trusted_updates"):
        def trusted_update_worker():
            # Verify this release before checking for another signed release.
            for _ in range(180):
                time.sleep(1)
                if not (UPDATES / "transaction.json").exists() and not (UPDATES / "atomic_transaction.json").exists():
                    os.environ["MASTERMIND_LIVE_PORT"] = str(port)
                    maybe_startup_auto_update()
                    return
        threading.Thread(target=trusted_update_worker, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping MasterMind...")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
