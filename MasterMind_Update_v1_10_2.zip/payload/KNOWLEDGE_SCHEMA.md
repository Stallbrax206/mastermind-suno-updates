# MasterMind Knowledge Patch Schema v1

The engine reads one canonical `KNOWLEDGE_PACK.json`. User changes are accepted only as small JSON patches and are stored outside versioned engine releases. A patch has any combination of `add`, `remove`, and `replace`; each section is an object whose keys are dot paths. Unknown paths, malformed entries, duplicate additions, invalid minimum counts, and every capitalization, separator, plural, `-ing`, or `-ed` form of the banned word **lowlight** are rejected before saving.

| Knowledge path | Valid entry |
| --- | --- |
| `lists.select_options.<control>` | Array of `{"value":"machine value","label":"visible label"}`. Controls: `lyricInfluence`, `rideContext`, `refStrength`, `perfStrength`, `projectSourceType`, `projectResearch`, `projectStrength`, `lyricLength`, `lyricPOV`, `lyricStructure`, `styleStrength`, `styleResearch`, `performanceDecodeStrength`, `performanceResearch`, `songResearch`, `conceptSourceType`, `conceptResearch`, `legacyPreserve`, `personaSex`, `personaRole`, `openBrowser`, `autoApplyUpdates`. |
| `lists.lyric_lexicon.<trait>` | Unique strings used by local lyric analysis. Traits: `playful`, `sensual`, `street`, `reflective`, `confidence`, `social`, `tension`, `warmth`. |
| `lists.route_stop_words` | Unique lowercase routing words. |
| `palettes.energy` | Unique visible energy-label strings. |
| `palettes.moods` | Unique objects: `{"name":"...","mechanics":"transferable production behavior"}`. |
| `palettes.colors` | Unique objects: `{"name":"...","mechanics":"instrument/texture behavior"}`. |
| `palettes.contrast` | Unique visible section-contrast strings. |
| `palettes.production_intents` | Unique objects: `{"name":"...","mechanics":"observable production intent translated into groove, sound, or arrangement behavior"}`. |
| `palettes.drum_characters` | Unique objects: `{"name":"...","mechanics":"kick, backbeat, hat, and percussion behavior"}`. |
| `palettes.bass_behaviors` | Unique objects: `{"name":"...","mechanics":"low-end movement, sustain, suspension, or answer behavior"}`. |
| `palettes.harmonic_worlds` | Unique objects: `{"name":"...","mechanics":"voicing, interval, motif, and harmonic movement behavior"}`. |
| `palettes.texture_spaces` | Unique objects: `{"name":"...","mechanics":"texture, width, decay, density, and room behavior"}`. |
| `palettes.arrangement_motions` | Unique objects: `{"name":"...","mechanics":"section-to-section motion, lift, subtraction, or return behavior"}`. |
| `palettes.vocal_spaces` | Unique objects: `{"name":"...","mechanics":"how the production protects and frames the lead vocal"}`. |
| `recipes.production_worlds` | Unique objects with `family`, `name`, `genre`, numeric `bpms[]`, and `instruments[]`. |
| `recipes.ride_contexts` | Object keyed by context; each value has `phrase` and `explain`. |
| `recipes.production_architectures` | Unique objects with `id`, `name`, `short`, `movement`, `drums`, `bass`, `relationship`, `surface`, and `arrangement`. |
| `presets.artists` | Object keyed by artist ID. Each artist contains identity, vocal/persona rules, EXCLUDE rules, and optional a-cappella requirements. |
| `presets.style_shortcuts` | Unique complete Style DNA objects identified by `id`, `reference`, or `name`. |
| `presets.producers` | Unique complete Production DNA objects identified by `id`, `reference`, or `name`. |
| `presets.styles` | Unique complete style-bank objects identified by `id`, `reference`, or `name`. |
| `presets.blueprints` | Unique complete construction-blueprint objects identified by `id`, `reference`, or `name`. |
| `defaults.select_values` | Object mapping a select control ID to its default value. |
| `defaults.exclude` | Unique default Suno EXCLUDE strings. |
| `defaults.persona` | Fallback `artist_type`, `artist_type_guardrail`, `age_presence`, `currentness`, and `cultural_vocal_language`. |
| `defaults.artist_key`, `family`, `energy_index`, `mood_index`, `contrast_index`, `max_style_chars` | Scalar defaults of the indicated type. |
| `rules.mechanical_language` | Objects with a valid regex `pattern` and plain-language `replacement`. |
| `rules.acapella_requirements` | Unique requirement strings. |
| `rules.banned_words` | Engine-protected list; patches cannot change it. |
| `templates.acapella_lyrics` | Object keyed by artist ID or `female_default` / `male_default`; value is a complete sample string. |

## Patch operations

- `add`: target a list to append one item or an array of items; target an object with an object of new keys. Existing identities/keys are rejected as duplicates.
- `remove`: target a list with one identity or an array of identities; target an object with one key or an array of keys.
- `replace`: target one existing field. A list item can be selected by its exact `id`, `reference`, `name`, `value`, or `label`, such as `palettes.moods.Dark controlled.mechanics`.

### Example 1 — add two knowledge entries

```json
{
  "add": {
    "palettes.energy": ["Measured lift"],
    "lists.lyric_lexicon.confidence": ["quiet leverage"]
  }
}
```

### Example 2 — replace one field and remove one exact entry

```json
{
  "replace": {
    "recipes.ride_contexts.alone.explain": "Focused solo movement with reflective space but no loss of rhythmic life."
  },
  "remove": {
    "palettes.contrast": ["Low — subtle section shifts"]
  }
}
```
