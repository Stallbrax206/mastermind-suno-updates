from __future__ import annotations

import importlib.util
import json
import py_compile
import re
import sys
import tempfile
from collections import Counter
from pathlib import Path

from release_integrity import checks_ok, load_contract, validate_release

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
HTML = ROOT / "static" / "index.html"
PROD_REQ = ["primary_engine","rhythm","drums","bass","relationship","harmony","texture","density","arrangement","transitions","vocal_space","mix","guardrail"]


def load(name, default):
    try:
        return json.loads((DATA / name).read_text(encoding="utf-8"))
    except Exception:
        return default


def missing_prod(x, rhythm_key="rhythm"):
    miss=[]
    for k in PROD_REQ:
        key = rhythm_key if k=="rhythm" else k
        if not str(x.get(key) or "").strip(): miss.append(k)
    inst=x.get("instrument_bias")
    if not isinstance(inst,list) or not any(str(v or "").strip() for v in inst): miss.append("instrument_bias")
    return miss


def check(name, ok, detail=""):
    print(("PASS" if ok else "FAIL") + f" | {name}" + (f" | {detail}" if detail else ""))
    return bool(ok)


def normalize(s):
    return re.sub(r"[^a-z0-9]+"," ",str(s or "").lower()).strip()


def exact_producer(producers, q):
    n=normalize(q)
    hits=[]
    for p in producers:
        terms=[p.get("reference"),*(p.get("aliases") or [])]
        if any(normalize(t)==n for t in terms): hits.append(p.get("reference"))
    return hits


def source_contains(path: Path, *needles: str) -> bool:
    text=path.read_text(encoding="utf-8",errors="replace")
    return all(n in text for n in needles)


def import_module(name: str, path: Path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


def main():
    ok=True

    # Compile the three shared release/update surfaces first.
    for filename in ("app.py","update_manager.py","release_integrity.py","knowledge_manager.py"):
        try:
            py_compile.compile(str(ROOT/filename), cfile=str(Path(tempfile.gettempdir()) / ("mm-check-" + filename + ".pyc")), doraise=True)
            ok &= check(f"{filename} compiles", True)
        except Exception as e:
            ok &= check(f"{filename} compiles", False, e)

    # SINGLE SOURCE OF TRUTH: release contract drives version/UI/backend/hash checks.
    try:
        contract=load_contract(ROOT)
        release_checks=validate_release(ROOT)
        rel_ok,_=checks_ok(release_checks)
        for c in release_checks:
            # Lack of a browser handshake is only a warning in offline regression.
            if c.get("severity")=="warn" and not c.get("ok"):
                print(f"WARN | Release contract: {c['name']} | {c['detail']}")
            else:
                ok &= check(f"Release contract: {c['name']}", c.get("ok"), c.get("detail"))
        ok &= check("Release contract validation aggregate", rel_ok, f"v{contract.get('version')}")
    except Exception as e:
        ok &= check("Release contract loads", False, e)
        contract={}

    producers=load("producer_bank.json",[]); styles=load("style_bank.json",[]); blue=load("blueprint_bank.json",[])
    ok &= check("Producer bank count", len(producers)>=int(contract["data_requirements"]["data/producer_bank.json"]["min_count"]), str(len(producers)))
    bad=[(x.get("reference"),missing_prod(x)) for x in producers if missing_prod(x)]
    ok &= check("Producer mechanical completeness", not bad, str(bad[:3]))
    ok &= check("Style bank count", len(styles)>=int(contract["data_requirements"]["data/style_bank.json"]["min_count"]), str(len(styles)))
    bad=[(x.get("name"),missing_prod(x)) for x in styles if missing_prod(x)]
    ok &= check("Style mechanical completeness", not bad, str(bad[:3]))
    ok &= check("Blueprint bank count", len(blue)>=int(contract["data_requirements"]["data/blueprint_bank.json"]["min_count"]), str(len(blue)))
    bad=[]
    for x in blue:
        probe=dict(x); probe["rhythm"]=x.get("rhythm") or x.get("groove"); probe["instrument_bias"]=x.get("instrument_bias") or ([x.get("instruments")] if x.get("instruments") else [])
        m=missing_prod(probe)
        if m: bad.append((x.get("name"),m))
    ok &= check("Blueprint mechanical completeness", not bad, str(bad[:3]))

    for label, items in (("Producer",producers),("Style",styles),("Blueprint",blue)):
        fps=[str(x.get("mechanical_fingerprint") or "").strip().lower() for x in items]
        d=[k for k,v in Counter(x for x in fps if x).items() if v>1]
        ok &= check(f"{label} fingerprint uniqueness", not d, str(d[:3]))

    expected={"Southside","Wheezy","Rogét Chahayed","FnZ","b4u","G. Ry","DJ Dahi"}
    refs={str(x.get("reference") or "") for x in producers}
    ok &= check("2026 producer additions present", expected.issubset(refs), str(sorted(expected-refs)))
    ok &= check("Partial-name false match blocked: Conductor Williams", exact_producer(producers,"Conductor Williams") in ([],["Conductor Williams"]), str(exact_producer(producers,"Conductor Williams")))
    ok &= check("Mike WiLL exact match still works", exact_producer(producers,"Mike WiLL Made-It")==["Mike WiLL Made-It"], str(exact_producer(producers,"Mike WiLL Made-It")))

    html=HTML.read_text(encoding="utf-8",errors="replace")
    # Regression gates for old leakage/persistence failures. These are behavioral implementation gates,
    # not version/schema markers. UI existence itself is contract-driven above.
    gates=[
        ("candidate/applied production separation", "productionApplied"),
        ("active-layer visibility", "ACTIVE LAYERS"),
        ("concept production isolated", "activeConceptProduction"),
        ("performance applied gate", "performanceApplied"),
        ("primary engine gate", "activePrimaryEngine"),
        ("universal textarea clipboard tools", "installClipboardTools"),
        ("local culture read varies from lyric behavior", "function localCultureRead"),
        ("project fit router remains suggestion-first", "SEND TOP PRODUCER TO STYLE DECODER"),
        ("orchestration control center exists", "MASTER ORCHESTRATION CONTROL CENTER"),
        ("orchestration authority is explicit", "newest explicit user instruction"),
        ("orchestration modes preserve user control", "Auto — fill empty unlocked fields only"),
        ("final package keeps three separate fields", all(x in html for x in ("packageLyrics","packageStyle","packageExclude"))),
        ("album continuity ledger exists", "ALBUM CONTINUITY LEDGER"),
        ("saved stack fingerprint gate exists", "validateSavedProjectCoherence"),
        ("maturity/currentness are separate controls", "MATURITY / CURRENTNESS SPLIT"),
        ("artist type survives into final style", "Artist type:"),
        ("persona style auto-fit exists", "function fitPersonaStyleToLimit"),
        ("live browser contract reporter exists", "function collectUIReport"),
    ]
    for label,marker in gates:
        ok &= check(label, marker if isinstance(marker,bool) else marker in html)

    orchestration_functions=("inspectOrchestration","applyOrchestrationSuggestions","buildFinalSunoPackage","auditAlbumContinuity","validateSavedProjectCoherence")
    ok &= check("Orchestration functions are registered", all(f"function {name}" in html for name in orchestration_functions))
    ok &= check("Approved lyrics remain exact in final package", "const lyrics=$('lyricsInput').value" in html and "$('packageLyrics').value=lyrics" in html)
    ok &= check("Final package separates STYLE and EXCLUDE polarity", "function separateStyleAndExclude" in html and "negative clause(s) moved out of STYLE" in html)
    ok &= check("Lyric prompt receives project, performance, and production context", all(x in html for x in ("PROJECT / ALBUM — WHERE","PERFORMANCE — HOW","PRODUCTION CONTEXT — WHAT")))

    # Knowledge is a runtime data surface, not a second copy embedded in the engine/UI.
    try:
        km=import_module("mm_knowledge_test",ROOT/"knowledge_manager.py")
        knowledge=json.loads((ROOT/"KNOWLEDGE_PACK.json").read_text(encoding="utf-8"))
        knowledge_errors=km.validate_pack(knowledge)
        ok &= check("Canonical knowledge pack validates", not knowledge_errors, str(knowledge_errors[:5]))
        scan=json.loads(json.dumps(knowledge));scan.get("rules",{}).pop("banned_words",None)
        ok &= check("Banned lowlight forms absent from knowledge", not km.forbidden_hits(scan,skip_rule=False))
        patched,changes=km.apply_patch_document(knowledge,{"add":{"palettes.energy":"Regression energy"},"replace":{"defaults.select_values.rideContext":"highway"}})
        ok &= check("Knowledge add/replace patch produces exact diff", len(changes)==2 and patched["defaults"]["select_values"]["rideContext"]=="highway",str(changes))
        try:
            km.apply_patch_document(knowledge,{"add":{"palettes.energy":knowledge["palettes"]["energy"][0]}})
        except km.KnowledgeError:
            duplicate_blocked=True
        else:
            duplicate_blocked=False
        ok &= check("Duplicate knowledge addition is rejected",duplicate_blocked)
        try:
            km.apply_patch_document(knowledge,{"add":{"lists.route_stop_words":"LOW/LIGHTING"}})
        except km.KnowledgeError:
            banned_blocked=True
        else:
            banned_blocked=False
        ok &= check("Banned lowlight variants are rejected",banned_blocked)
    except Exception as e:
        ok &= check("Knowledge manager runtime validation",False,e)

    ok &= check("Knowledge UI is populated from the pack", "function configureKnowledge" in html and "KNOWLEDGE.palettes.energy" in html)
    ok &= check("Legacy energy array is not embedded in UI", "const ENERGY=[" not in html)
    ok &= check("Knowledge patch and preset transfer controls exist", all(x in html for x in ("knowledgePatch","applyKnowledgePatch","exportKnowledge","exportPresets","importPresets")))

    app_text=(ROOT/"app.py").read_text(encoding="utf-8",errors="replace")
    ok &= check("Backend loads effective knowledge pack", "def effective_knowledge()" in app_text and "KNOWLEDGE_PACK_PATH" in app_text)
    ok &= check("Knowledge and preset transfer routes exist", all(x in app_text for x in ("/api/knowledge/export","/api/knowledge/patch","/api/presets/export","/api/presets/import")))
    ok &= check("Trusted update channel bootstrap exists", "def ensure_trusted_update_channel()" in app_text and "REMOTE_UPDATE_MANIFEST_URL" in app_text)
    try:
        trust=json.loads((ROOT/"UPDATE_TRUST_BOOTSTRAP.json").read_text(encoding="utf-8"))
        key=next(iter(trust.get("keys",{}).values()))
        ok &= check("Production update public key is RSA-3072", int(key["n"],16).bit_length()>=3072 and int(key["e"])==65537)
    except Exception as e:
        ok &= check("Production update public key loads",False,e)
    ok &= check("AI Style schema includes drum/bass relationship", "rhythm, drums, bass, relationship, harmony" in app_text)
    ok &= check("Incomplete AI production is blocked", "require_production_dna(style, \"AI Style DNA\")" in app_text)
    ok &= check("Saved song lanes validated", "require_production_dna(item.get(\"production\")" in app_text)
    ok &= check("Project DNA schema is validated", "PROJECT_REQUIRED" in app_text and "require_project_dna" in app_text)
    ok &= check("Persona AI requires sung 60-90 second sample", "60–90 seconds of usable continuous solo vocal" in app_text and "130–180 words" in app_text and "SUNG THROUGHOUT" in app_text)
    ok &= check("Persona a cappella EXCLUDE field is wired", "acapellaExclude" in html and "acapella_exclude" in app_text)
    ok &= check("Production direction controls are user-selectable", all(x in html for x in ("productionIntent", "drumCharacter", "bassBehavior", "harmonicWorld", "textureSpace", "arrangementMotion", "vocalSpace", "productionDirection")))
    ok &= check("Persona AI preserves cultural performance language", "CULTURAL PERFORMANCE RULE" in app_text and "generic pop diction" in app_text)
    ok &= check("Persona AI separates artist type", "ARTIST TYPE HARD RULE" in app_text)
    ok &= check("Persona AI hard-separates maturity/currentness", "MATURITY / CURRENTNESS HARD RULE" in app_text and "NEVER translate maturity into slower tempo" in app_text)
    ok &= check("Performance decoder preserves adult/current separation", "AGE / CURRENTNESS SEPARATION" in app_text)

    artists=load("artist_dna.json",{})
    marcell=artists.get("marcell_vance",{})
    ok &= check("Marcell cultural vocal language present", "Black American R&B" in str(marcell.get("cultural_vocal_language") or ""))
    ok &= check("Marcell 60-90 a cappella target", str((marcell.get("acapella") or {}).get("length_seconds"))=="60-90")
    ok &= check("Marcell a cappella excludes present", len((marcell.get("acapella") or {}).get("exclude") or []) >= 8)
    pack=json.loads((ROOT / "KNOWLEDGE_PACK.json").read_text(encoding="utf-8"))
    palette=pack.get("palettes", {})
    ok &= check("Expanded production option palettes present", all(len(palette.get(k, [])) >= 8 for k in ("production_intents", "drum_characters", "bass_behaviors", "harmonic_worlds", "texture_spaces", "arrangement_motions", "vocal_spaces")))
    ok &= check("Expanded production worlds present", len(pack.get("recipes", {}).get("production_worlds", [])) >= 18)
    ok &= check("Marcell mature adult presence lock", "mature adult" in str(marcell.get("age_presence") or "").lower(), str(marcell.get("age_presence") or ""))
    ok &= check("Marcell current rhythmic mobility lock", "140–154" in str(marcell.get("currentness") or "") and "youth" in str(marcell.get("currentness") or "").lower(), str(marcell.get("currentness") or ""))
    ok &= check("Marcell artist type defined", "grown contemporary melodic r&b rider" in str(marcell.get("artist_type") or "").lower(), str(marcell.get("artist_type") or ""))
    ok &= check("Marcell artist type blocks youth/crooner drift", "boyish" in str(marcell.get("artist_type_guardrail") or "").lower() and "croon" in str(marcell.get("artist_type_guardrail") or "").lower(), str(marcell.get("artist_type_guardrail") or ""))

    # Shared updater/release-engineering gates.
    try:
        um=import_module("mm_update_test",ROOT/"update_manager.py")
        ok &= check("Project DNA protected at runtime", um.is_protected("data/custom_project_dna.json"))
        ok &= check("Future custom user-data auto-protected", um.is_protected("data/custom_future_module.json"))
        ok &= check("Update transaction recovery exists", hasattr(um,"recover_incomplete_transaction"))
        ok &= check("Shadow-install validation exists", hasattr(um,"validate_shadow"))
        ok &= check("Restarted runtime health verification exists", hasattr(um,"verify_restarted_runtime"))
    except Exception as e:
        ok &= check("Updater runtime import", False, e)

    um_text=(ROOT/"update_manager.py").read_text(encoding="utf-8",errors="replace")
    update_gates=[
        ("Updater requires manifest hashes", "valid SHA-256"),
        ("Updater blocks downgrade/same version", "Refusing non-newer update"),
        ("Updater checks min/max version compatibility", "from_version_min"),
        ("Updater requires release contract", "Update is missing required"),
        ("Updater forbids protection weakening", "weakens user-data protection"),
        ("Updater stages full candidate before live commit", "validate_shadow(stage, files, temp_root)"),
        ("Updater prepares all files before commit", "prepare_commit(stage, files)"),
        ("Updater journals commit progress", 'journal["phase"] = "COMMITTING"'),
        ("Updater recovers interrupted transactions", "recover_incomplete_transaction()"),
        ("Updater snapshots user data", "snapshot_user_data"),
        ("Updater verifies protected user data unchanged", "Protected user data changed during update"),
        ("Updater verifies restarted runtime", "verify_runtime(runtime_proc, ROOT, port, incoming_version"),
        ("Update rollback restores program backup", "restore_backup(backed, created, backup_dir)"),
    ]
    for label,needle in update_gates:
        ok &= check(label, needle in um_text)

    # Runtime validators should reject incomplete Project DNA without relying on UI markers.
    try:
        mod=import_module("mm_app_test",ROOT/"app.py")
        sample={
            "reference":"Test Project","source_type":"MY PROJECT","project_premise":"A coherent original project",
            "sonic_spine":"moving rhythm section with song-specific lead carriers",
            "production_evolution":"increase density selectively across the sequence",
            "performance_arc":"controlled opening, broader middle, resolved close",
            "concept_progression":"establish world, complicate stakes, resolve perspective",
            "energy_curve":"alternate pressure and breathing room without dead zones",
            "tempo_strategy":"cluster core tempos with selected contrast records",
            "hook_strategy":"vary room-facing, melodic, and restrained hooks by song job",
            "subject_distribution":"avoid repeating the same situation on adjacent songs",
            "sequencing_logic":"sequence by energy and concept consequence rather than random order",
            "track_roles":["opener","pressure single","intimate deep cut","closer"],
            "routing_keywords":["moving bass","hard clean drums","restrained harmony","section contrast"],
            "project_overlay":"preserve forward rhythmic motion, clear song-to-song contrast, and a consistent vocal-first center",
            "cohesion_guardrail":"share principles, not identical beats",
            "originality_guardrail":"do not copy a reference project's expressions or sequence"
        }
        ok &= check("Project DNA valid sample passes", not mod.project_missing(sample), str(mod.project_missing(sample)))
        broken=dict(sample); broken.pop("sonic_spine")
        ok &= check("Incomplete Project DNA is blocked", "sonic_spine" in mod.project_missing(broken), str(mod.project_missing(broken)))
    except Exception as e:
        ok &= check("Project DNA runtime validation", False, e)

    print("\nRESULT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1

if __name__=="__main__":
    raise SystemExit(main())
